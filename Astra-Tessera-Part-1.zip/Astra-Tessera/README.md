# Astra Tessera

Private, digital-first collecting proof of concept. An illustrated collector experience with original demo universes, vector cards and generated premium concept art. Commercial licensing and art collaborations are not connected.

## Run locally
Serve `dist` with any static HTTP server, for example:

```sh
python3 -m http.server 8000 --directory dist
```

Visit http://localhost:8000. ES modules need HTTP serving rather than opening index.html as a file. No dependency installation or build is needed. Saves live in browser localStorage; Export save produces a portable catalog+state JSON backup. The export includes all owned quantities and simulated printing history.

## Test

```sh
node --test tests/*.test.mjs
```

The tests cover transactional accounting, guarantees, duplicates, crafting, archive compatibility, save import validation, print entitlement protection and a 300-pack accounting simulation. The UI smoke test uses minimal DOM stubs to check rendering and event wiring. It is not real browser, layout or accessibility verification.

## Modules
- dist/catalog.js: content and provisional economy.
- dist/core.js: pure state transitions and schema validation.
- dist/art.js and dist/scene-art.js: original SVG portraits, environments and props.
- dist/app.js: UI and browser persistence.
- dist/styles.css: responsive design, franchise frames and direct-interaction animations.
- docs/PRODUCT_PLAN.md: confirmed vision, proposals, architecture, commercial planning and open decisions.

## Deliberate limits
No login/accounts, server inventory ledger, cross-device synchronization, real payments, physical fulfillment or third-party franchise content. Local balances/ownership are editable and have no monetary value. Import replaces this browser's demo after validation and confirmation. New cards/collections use stable IDs; archive owned content rather than deleting it. Prototype rules and print pricing are hypothetical and configurable. This is not a launch-ready system.

## Edition 02
Two original illustrated collections: Chaos Crew and Discount Dungeon, 20 cards each. Card names, roles and visual jokes are in English. There are no card gameplay rules. Pack tearing, card flips and rarity-specific reveals can be disabled; reduced-motion preferences are respected. Sound is opt-in and synthesized locally, without external audio assets.

Existing first-edition saves are upgraded once. Original cards are archived, with balances, quantities, custom content, print entitlements and history preserved. Save exports remain portable. New content does not reset the user’s economy settings.

## Edition 03
The binder opens into chosen franchise folders; owned cards are shown first, with a per-folder Show missing cards toggle. Folder choices are part of save exports; removing a folder does not remove ownership. Pack opening offers a clickable seal with a franchise theme. Draws are saved before any animation. Presentation sorting preserves exact pulls and odds, ordering common through legendary. A face-down offset stack flips one card, then files each card into a right-hand column while showing the next. Interaction is locked during flips/moves, with skip and reduced-motion alternatives.

## Edition 04
Three original 20-card universes, including Orbital Oddjobs. Scene artwork adds environments, mechanical details, costumes and joke-specific props. Frames combine franchise character and rarity; a subtle illustration watermark sits behind card copy. Discovery, binder, opening table, artist gallery and print studio use related but distinct surfaces.

Opening rituals: foil slider (Chaos), three chest strikes (Dungeon), directional delivery code followed by a landing pod (Orbital). Button/keyboard autoplay completes the inputs and plays the same cinematic. The first two openings per universe stay at normal speed; the third offers a persistent normal/fast choice, also configurable in Workshop. Motion reduction bypasses animation.

Stack updates retain previously filed rail DOM nodes. Only a newly occupied slot gets an arrival animation; flip completion clears classes and enables controls without rebuilding the page. The regression tests check node retention separately from layout. All 60 original SVGs were structurally validated and a sample art sheet visually inspected; actual browser layout, animation timing and touch behaviour remain unverified in this environment.

## Edition 05 — Astra Tessera
- Rebuilt discovery with a five-slide universe/community/merch carousel and selected-franchise progress.
- Illustrated spaces for discovery, binder shelves, opening table, collector lounge and print atelier.
- Three new universe paintings and three premium card portraits, compressed to WebP. Stable catalog IDs preserve ownership.
- Franchise frames, illustrated backs, readable card text, fictional studio credits and foil reacting to pointer position.
- Binder covers, manual order, sort/search/ownership/rarity filters, favourites and wishlists. Three free skins; an 8% extra cosmetic chance in packs.
- Saved multi-pack queues and current reveal position. Chest/key, delivery-code and directly draggable foil-strip rituals; autoplay and speed preferences.
- Cards can be dragged to reveal and file. Next uses shorter transitions. Previously filed rail slots are not replaced or reanimated.
- Protected cards and print reservations are excluded from recycling. Bulk filtered preview; last copies require two confirmations.
- Local collector identity, three-card showcase, fictional community follows/likes and local posts.
- Simulated franchise merchandise and combined card-print parcels with one delivery estimate.

Validation: 41 automated tests cover domain accounting, migration, persistence and DOM-stub event wiring. Interactive ritual button and pointer paths are included. The supported browser QA capability was unavailable; actual layout, drag feel, animation timing and browser accessibility were not visually verified. No live social service, payment processor or shipping system is connected.

## Edition 06 — physical collecting and a complete illustration pass
The 40 written review annotations are tracked in `docs/EDITION_06_BRIEF.md`. The new edition adds dedicated illustrated card and pack assets, live appearance previews, six free binder colour channels, holographic/scroll/flight-case binder structures, illustrated room backgrounds, a timed discovery carousel with pause and editorial updates, and richer profile customization.

Pack stores stay within the chosen franchise and offer visual single/loose bundle/collector-box options. New purchases are prioritized as a batch without dropping previous waiting packs. Multi-pack batches advance automatically (toggle available), Next sits below the stack, and Open all collects the current batch in one summary. A real lid-and-interior model replaces the stretched-pack box.

Pointer movement uses a scheduled animation frame; foil coordinates are measured against the actual shine surface. Face-down cards can be moved without flipping; visible cards tilt in the drag direction. Lower stack layers show the universe back design. Pack manipulation works in the store and during foil opening, and dungeon keys visibly turn before unlocking.

Artist Back restores the source card dialog, filters and scroll. Showcase slots open an inline universe/card chooser. Favourite-game tags and a manually entered Steam profile link are local profile fields, not a connected Steam integration. Site news is editorial prototype news, not a live external feed.

Validation includes batch priority, automatic progression, hidden-card drag, artist return, free colour persistence and URL validation. Browser layout and animation feel remain unverified because the supported browser QA capability is unavailable.

## Edition 07 — five worlds and interaction refinement

Adds Clockwork Couriers and Moonlit Menagerie (40 new illustrated cards) with collision-safe IDs, independent packs, collectible binder covers and different opening mechanisms. Existing saves migrate additively; the legacy archived `clockwork` collection remains intact.

The 21 review notes are tracked in `docs/EDITION_07_BRIEF.md`. This pass changes whole-card proportions, physical frames, sleeve fit, pointer handling, pack inspection and purchase flow, binder dragging, expanded colours, page/density previews, theme previews, showcase ordering and direct navigation, and individual franchise collecting surfaces. A full-art inspection preserves access to the complete illustration.

Quality status: functional prototype with a substantial visual refinement, not production-ready. Generated imagery is concept art. Automated checks cover data and interaction state; no actual browser visual QA is available in this environment. Final animation smoothness, touch hit-testing and responsive composition require browser verification. Community, payment and fulfilment remain explicitly simulated.
