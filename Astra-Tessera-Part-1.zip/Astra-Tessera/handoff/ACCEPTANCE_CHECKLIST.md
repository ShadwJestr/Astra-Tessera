# Acceptance and regression checklist

Use real browser interaction when available. Automated tests supplement, not replace, these checks. Test at 1304×884 and 1944×1244 initially. Mobile is a separate later design phase; don't introduce obvious overflow meanwhile. Preserve user data by testing a copied/exported save or fresh isolated browser profile.

## Transfer readiness
- [ ] All dist JS/CSS/assets resolve locally over HTTP; console has no startup errors.
- [ ] Existing source tests pass; note environment/runtime.
- [ ] Old deployed private site remains unchanged by local testing.
- [ ] Main export/import can move a copied save between hosted origin and localhost without quantity loss.
- [ ] Publication access is verified separately, or clearly marked unavailable.

## Opening controls and interaction matrix
Repeat with a normal five-card pack and a cosmetic sixth-card pack.
- [ ] Reveal Y position equals Next Y position equals Another pack Y position within 1px, before/after animations settle.
- [ ] No overlap between back stack and control; completion panel width/height matches card.
- [ ] Stationary pointerdown/up reveals one card exactly; no extra filing from synthetic click.
- [ ] Small involuntary jitter still counts as click.
- [ ] Deliberate hidden-card drag does not reveal or file.
- [ ] Lower cards show backs only; cannot interact with underneath cards.
- [ ] Visible-card click files once and next front appears automatically.
- [ ] Drag direction gives fluid sideways/in-plane lean, not rigid translation or pack orbit.
- [ ] Cursor shine follows actual foil surface without lag/vertical offset.
- [ ] Corners do not jitter or clip sleeves.
- [ ] Upper bound gives expected travel; left/right/lower boundaries remain correct.
- [ ] Drop guide appears before release; hovering over it does not file.
- [ ] Release in zone files once; release elsewhere springs home; pointercancel does not file.
- [ ] Right column does not flicker or replay earlier arrival animations.
- [ ] Next is faster; double-click and rapid Space do not duplicate/skip/charge twice.
- [ ] Legendary and cosmetic presentations don't change inventory or layout anchors.
- [ ] Last-card file centres completion; singular/plural correct; secondary actions below.
- [ ] Reduced motion completes same state transitions without getting stuck.
- [ ] Scroll on entry shows table; Back accessible by slight upward scroll/sidebar/bottom actions.

## Packs and queue
- [ ] Pack/store/inspection/opening manipulation consistent; reset on release without jump.
- [ ] Foil drag tears actual seam; key inserts/turns once; no duplicate key.
- [ ] Direction arrows consistent; autoplay/skip works through each ritual.
- [ ] Wrong directional input resets appropriately; correct input completes.
- [ ] Box shows correct world, quantity, lid/interior/packs.
- [ ] New purchase prioritizes its own world/batch without discarding old waiting packs.
- [ ] Batch automatic next optional; repeat purchase preserves quantity.
- [ ] Open all summary closes to same table.
- [ ] Insufficient credits clearly explained and does not mutate state.
- [ ] Reload/skip during animation preserves committed pulls exactly.

## Binder and showcase gestures
- [ ] Same-row and cross-row binder drops swap only two items.
- [ ] All unrelated binder positions unchanged.
- [ ] Target progressively approaches vacated slot; retreat reverses it; no sudden premature save.
- [ ] Off-target release/cancel restores; valid release saves and survives reload.
- [ ] Showcase insertion retains smooth neighbour preview and only saves on release.
- [ ] Stationary showcase click opens selected detail; drag does not open modal.
- [ ] Artist credit and showcase arrow/control buttons do not start unwanted drag.
- [ ] Keyboard/button reorder alternatives remain.

## Design Lab
- [ ] Open scene permits any combination of detail checkboxes.
- [ ] Enable three details; disable middle; other two remain visibly enabled.
- [ ] Toggle details without losing focus/pickup/reveal progress.
- [ ] Change architecture/world; inspect expected retention/reset rules.
- [ ] Save/restore combination retains every enabled/disabled option and material/motion preference.
- [ ] Resting stack lies on pictured foreground desk.
- [ ] Manual pickup remains lifted on release; does not reveal face.
- [ ] After pickup, click/drag/Next/drop behaves like normal opening.
- [ ] Hidden sample drag doesn't reveal; only top card grabbable.
- [ ] Right filing flight goes to intended area; physical receiver doesn't block text/drop region.
- [ ] Reset/switch world during animation cannot mutate the new scene through stale callback.
- [ ] All five samples progress exactly once; samples never alter actual inventory/credits.
- [ ] Sleeve follows full card, retains border and material effect; balanced default.
- [ ] Architecture visibly distinct; frames and objects match perspective and don't cover cards.
- [ ] Atmosphere belongs to world; reduced motion stops ambient motion.

## Navigation and detail context
- [ ] Back from artist restores exact card modal, source collection, page, filters and scroll.
- [ ] Showcase picker stays modal: universe → card → selected slot.
- [ ] Showcase dropdown closes back to detail.
- [ ] Other collector links open other collector room/profile.
- [ ] Correct nav highlight; Opening table and My showcase easy to find.
- [ ] Catalog/binder side arrows follow scroll; no redundant bottom arrows.
- [ ] Customizer outer dimensions stable across filters; selector inner-scroll only; colours fit.
- [ ] No native image dragging in previews.

## Data/accounting
- [ ] Add worlds/content without losing legacy archives/custom edits.
- [ ] Owned counts, locks, printed/reserved copies and pending queue survive export/import/reload.
- [ ] Recycling common spares, last-copy double confirm, protected refusal, high-rarity safeguards.
- [ ] Bulk recycle preview equals result; cancellation no mutations.
- [ ] Duplicate cosmetic automatically converts once and records correct result.
- [ ] Print only available entitlement; equal rarity-independent unit price; combined parcel consistent.
- [ ] Bad import leaves existing save untouched; corrupt storage not silently overwritten.
- [ ] Milestones/journal do not invent legacy dates or double-award rewards.

## Visual approval — record separately
- [ ] Current scene choice approved by Ravn, or clearly still Lab experiment.
- [ ] Actual previews reflect chosen final rooms (deferred until choice).
- [ ] Dedicated page art fits its space; long print page doesn't end in accidental blankness.
- [ ] Cards, binders, packs, merch, reward previews and small shelf assets all receive attention.
- [ ] Readable English flavour tied to image; no missing copy or excessive tutorial clutter.
- [ ] No claim of final art before reference folders and user review.
