# ASTRA TESSERA — COMPLETE CONTINUATION HANDOFF

Prepared 11 October 2026 for Ravn and the next coding agent. Previous working agent: Rook. Snapshot: Edition 15, source commit `a54106f3bb8b37d50b1f618d1d70d06e35a5b922`.

This document is deliberately long. Read it before treating any existing feature as final or proposing a restart. It preserves the product, design preferences, interaction contracts, feature scope, failure history and transfer procedure. The accompanying annotation history and historical documents supply additional depth. This is NOT a verbatim export of the entire conversation; no claim is made that every past message or missing image was recovered. It is a source-grounded handoff based on the available conversation and project files. Do not invent remembered details.

## 1. What we are building

Astra Tessera is a digital-first, multi-universe collectible-card platform and proof of concept. The core pleasure is discovering a world, opening beautifully presented randomized packs, collecting illustrated cards, arranging a binder/collector room and showing the collection to others. The cards do not need game rules, combat stats, decks or competitive play. The user explicitly allowed fake TCG universes and non-playable cards.

The long-term concept includes officially licensed franchise collaborations and paid artists with distinct styles. Digital pack purchases would be inexpensive, with exact ownership quantities. Optional physical cards would be printed only from owned entitlements, with manufacturing/shipping costs rather than rarity-based markups. Combining prints, merchandise and binders could make shipping more efficient. This is a business concept, not a connected commercial service.

Current scope is entirely simulated: credits, recycling fragments, ownership, orders, products, social activity and creator identities are prototype data. The user clarified that unless someone picks up the idea, real selling may never happen: people can simply collect fake cards. Do not treat monetization, accounts, official IP licensing or a backend as prerequisites to polishing this proof of concept.

The user wants the prototype to communicate the real idea convincingly. “Simulated” is not permission for bland rectangular placeholder surfaces. Merchandise, packs, binders, table rewards, previews and peripheral pages matter as much as hero artwork. A finished-feeling experience matters even when checkout remains fake.

## 2. Identity and deployment — preserve these

- Product name: **Astra Tessera**. Earlier project name: Card Atlas / Rook Card Atlas. Old technical IDs and URL remain valid and should not be renamed casually.
- Existing private URL: https://rook-card-atlas.silly-llama-9439.chatgpt.site/
- Exact Site project ID: `appgprj_6ac94ebb79288191a53ff0e0d752dacf`.
- Last confirmed deployment: `appgdep_6acb5762628881918e6dc32712b7b33b`, succeeded.
- Last saved Site version: `appgprj_6ac94ebb79288191a53ff0e0d752dacf~appgver_4a8becbd2ae48191859e804962f3cb43`.
- Last source commit: `a54106f3bb8b37d50b1f618d1d70d06e35a5b922`.
- Audience confirmed owner-private at last publication. Do not widen it or create another Site as a migration shortcut.
- Hosting manifest: `.openai/hosting.json`, static directory `dist`.
- Original cloud checkout: `/workspace/sites/rook-card-atlas`. This is historical, not a Windows path to use on the new machine.

A ZIP transfers files, not Site authority, cloud chat state or connector credentials. Check authenticated Sites access before promising live updates. If unavailable, work locally and explain the gap. Never put a token in Git, a prompt, a ZIP or a handoff. The included Git bundle has source objects/history, not the old checkout's config, credentials or hooks.

## 3. How Ravn wants collaboration to work

Ravn supplies many annotations quickly, often with typos. Interpret the intended concrete behaviour, not the spelling. They have repeatedly lost annotations due to attachment-count limits. Acknowledge text even when screenshots fail; do not require them to rewrite everything. Distinguish “I received the note” from “I saved an artifact” and from “I implemented it.”

The user wants independent, substantial work, not constant permission checks, micro-changes or offers to continue. When authorized to make a big update, do the work through validation and delivery. When told “not yet,” “still testing,” “still writing,” or “wait,” accumulate feedback and do not start modifying the site. A clarification during active work is usually steering, not cancellation.

Be realistic, concise and candid. Do not be a yes-man or promise a perfect site, zero regressions, exact memory of unavailable old animations, guaranteed hours of work, a visible usage percentage, or access to another chat that has not been retrieved. The user has given usage thresholds before; do not claim you can measure account quota if you cannot.

The user has explicitly complained about one step forward/two steps back. Repair neighbouring behaviour, not only the selected screenshot. Prefer shared interaction logic over divergent implementations. Do not trade away working clicks to implement dragging or lose fluid motion to enforce boundaries. Reproduce before fixing if browser tooling exists. Show what was tested and what was not.

They like bold creative initiative, but proposed unfamiliar visual directions belong in **Design Lab**. They explicitly authorized multiple experimental versions, mixed options and comparisons so the normal site does not have to be repeatedly rolled back. Limit elaborate table studies to two worlds for now to save effort/usage.

They want an honest distinction between placeholders and the eventual finished look. Do not make them repeat “this needs real art” for every item. Keep a persistent final-art checklist. Equally, do not tell them everything is merely intentionally unfinished when there are real bugs. Missing art, provisional art, poor design and broken behaviour are different categories.

Avoid importing unrelated sensitive personal context. Relevant taste: broad gaming interests, especially immersive game worlds, sci-fi, fantasy, steampunk, collecting/cosmetics and showing off. Titanfall, Helldivers, BG3, Minecraft and Apex were examples of distinct universe mechanics, not proof of licensing or commands to clone those assets. The dedicated art-reference folders promised by two other chats are not in this transfer. Ask for them when needed; never pretend to have read them.

## 4. The visual standard

The desired result should look thoughtfully art-directed, not like a cheap generic AI-generated site. Strong compositions, recognizable shapes, intentional materials, world-specific objects and readable hierarchy matter more than indiscriminate particles or microdetail. Avoid homogeneous generated blur/noise and repeated stock-like compositions. Multiple art styles may coexist across universes/creators. The user explicitly invited learning from references and making original art; eventual artist/reference packs will guide that.

One coherent platform identity should contain different spaces: Discovery is a storefront/editorial entry; binder is a collecting room; opening is an in-universe ritual/table; print/merch is a product/proof studio; profile/lounge is showing off. Simply changing the layout inside the same background is insufficient. Yet the navigation and interaction conventions should remain understandable.

Background paintings must be composed for their actual positions. Reusing one universe hero image everywhere is provisional. Wide foreground tables plus a landscape beyond are now the preferred Lab approach. Long pages may need a second related artwork where the content changes subject; don't let the bottom suddenly become empty. Slow, subtle parallax/background movement was positively received, but must not obscure content or fight scrolling.

A “table” is a 2D immersive interface, not a 3D game level and not necessarily a literal rectangle photographed from above. The user clarified: same basic functional structure, drastically different look/feel by universe. Materials, frame shapes, surrounding architecture, fittings and props should feel part of the IP. The frame should resemble an in-world object, not a generic translucent rounded panel. The page below the global currency/back bar should belong to that universe. Borders and details should grow substantially richer for milestone and collectible/prestige tables.

They liked the cleaner open-scene experiment without the semitransparent panel. This was a preference for exploration, not a final commitment to removing every panel. The right-hand “Your pulls” UI can remain, optionally integrated with a physical box receiving filed cards. Any object added onto a desk must match the image's perspective, lighting, scale and material language; random emoji over a background do not satisfy the final standard.

Dynamic backgrounds should feel alive: drifting dust/fireflies, distant movement, or an occasional ship in a suitable space world. They liked drifting motion and the idea of a living window into the universe. Uniform stars represented as plain dots were criticized. Effects need world relevance and quality, not merely more toggles.

## 5. Current worlds and stable identifiers

| Visible world | Stable collection ID | Direction |
|---|---|---|
| Chaos Crew | `recrues` | Comic squad/gaming/voice-chat disasters; neon/technical hardware |
| Discount Dungeon | `donjon` | Comic fantasy dungeon; wood, metal, runes, vaults, chest/key |
| Orbital Oddjobs | `orbital` | Space workers/cargo/robots; ship panels, delivery code/pod |
| Clockwork Couriers | `couriers` | Steampunk postal dispatch, brass machinery/gears |
| Moonlit Menagerie | `moonlit` | Midnight hotel of strange creatures; silver, velvet, moon garden |

Five active original sets, twenty cards each, with legacy/archived content also present. Never derive IDs by translating visible names. The old `clockwork` archive is not the active `couriers` world. Preserve legacy ownership and custom edits. Cards should have English names, subtitles and humour based on visible artwork. The user mentioned a Wankil-like absurd tone initially; do not imitate exact copyrighted jokes or make the writing French. Good examples from the project include silly visual contradictions, underqualified staff and ordinary objects treated as heroic.

Rarity presentation must show through edges/borders and effects. Each world should have its own frame construction as well as rarity colour. Cut corners can be intentional, but their final rendering must be clean, never twitch or accidentally clip the artwork/sleeve. Cards should resemble physical TCG proportions, around 5:7, not overly tall posters. The user approved recent card back paintings and improving front art, but did not approve all art as finished.

## 6. Feature inventory and current status

“Implemented” below means code exists. It does not mean final visual approval. Inspect the source and browser for exact current behaviour.

### Discovery and universes
- Featured carousel with editorial cards, timed rotation, pause/resume and directional navigation. Arrows belong at the left/right edges without heavy boxes; pause should look like two separated bars, not Roman numerals.
- Announce new worlds immediately in the feature area/What's new. Clockwork and Moonlit arrival should be visible rather than silently added.
- Potential featured content includes arrivals, news, recommended packs, social content and merchandise; current news is editorial simulated content, not an external live feed.
- Collecting stats should relate to chosen/favourite/started franchises, not all cards on the entire platform. Clicking missing totals should expose per-universe breakdowns.
- Universe-led navigation replaces a primary Artists destination. Artists still matter on cards/detail pages and have portfolios.
- Universe pages give identity/art/pack calls to action enough space before the card catalog. The catalog may start about a small scroll below the hero rather than overwhelming the initial view.
- Catalogs use pagination rather than extremely long card grids. Apply comparable patterns across all worlds, not just one annotated world.
- Global back, search, scroll-to-top and What's new exist. Preserve meaningful back context.

### Binder and collection
- User chooses franchise folders. Show owned cards; optionally show missing cards for that franchise.
- Exact copy quantities are part of ownership. Hiding/removing a folder must not delete cards.
- Archived/paused worlds remain navigable when owned; legacy saves must survive additions.
- Paged album: at most three rows per page, with page size responsive to columns. Side page arrows follow scrolling. Redundant bottom arrows were removed by request. Page-turn animation is present/provisional.
- Binder shelf supports arrangements, hidden/displayed binders and row/column choices. Binders should be compact enough to display several without huge scrolling.
- Physical binder forms and artwork: leather books, futuristic holo binders, scroll-like fantasy forms, cases/guestbooks. Unique cosmetics should change silhouette/material/art, not just a flat colour.
- Free colour selection, advanced trim channels and previews exist. True selective recolouring of illustration regions is NOT solved. User prioritizes beautiful binders over mediocre recolourable ones. Don't apply a global pink tint to the whole painting and call that six-part recolouring.
- Binder customization panel has filtered owned/unlockable/world choices, stable overall dimensions and a separate preview. Selector scrolls within its area; options should fit without excessive outer scroll. No accidental native image drag.
- Latest decision: drag a binder onto another to **swap those two places**, including across rows. Other rows remain unchanged. Preserve the progressive movement/leaning that was approved. This supersedes insertion of intervening binders.

### Card details, credits and protection
- Inspect enlarged card, art, role/flavour text, rarity/number, owned quantity, artist/studio credit, printable state and story/journal.
- Credits on both card and detail view open a creator page. Back returns to the exact source context—same card modal, collection/filter/page/scroll—rather than sending the user to a generic page.
- Card story sits below/near the left card to use space and shrink the dialog. Journal/acquisition history was praised. Legacy acquisition dates must be honest, not invented.
- Actions include print queue, wishlist, protect/unprotect, showcase and recycle. Recycle/wishlist/cover affordances must be adequately visible, not tiny.
- Protection sleeve follows the card's transform and shape. Show protection in collection grids too. Putting on AND removing the sleeve should animate visibly, with reduced-motion handling.
- Cosmetic sleeve experiments add light/material effects across the card and at least border effects, not a detached static rectangle. Gilded, leaf/garden and holographic studies exist. These were approved as a good direction.
- Small showcase preview/dropdown in the detail flow allows checking or changing showcase without losing the current card context.

### Recycling, completion and currency
- Single and bulk recycling with filters, preview, protection and safeguards.
- User permits recycling the last/unique copy with two warnings. High rarities need conspicuous protection without making every common duplicate annoying.
- Never recycle protected/printed/reserved entitlements incorrectly. Invalid operations must not partially charge/delete.
- Automatic duplicate cosmetic conversion for rooms/binders/future trinkets was explicitly requested. Current fragment values are provisional.
- Crafting/duplicate protection/guarantee rules help completion. Pack odds and rules should be inspectable.
- Full-set completion rewards/profile icons, milestones and an extra cosmetic chance were liked. Numerical economy is not finalized.
- Insufficient credits must produce clear feedback at purchase, not a silent dead button. Demo refill is permitted.

### Packs and boxes
- Pack store reached through a universe stays in that universe. No redundant franchise dropdown; go back to change worlds.
- Visual single/bundle/box quantities. Loose bundles show multiple physical packs; a box is a dimensional object with lid/interior and packs, not a stretched single pack.
- Pack art is distinct original artwork. Objects feel physical through volume, lighting and restrained perspective.
- Drag/rotate inspection works on the store display itself, in inspection dialog and during opening where applicable. Reset angle on release; a separate Reset angle button was considered unnecessary.
- Interaction area fills its intended display region without an awkward unused bottom-left gap. Avoid janky angle jumps.
- Ready to open preserves the inspected quantity/world and shows its price.
- Purchased batches retain identity/world/queue; a new selected purchase should not accidentally open another world's old queue first.
- Multi-pack openings run successively; a toggle is allowed. A box has its own world-specific opening before its packs. Repeat-purchase repeats the original quantity, not always one pack.
- Open all at once summarizes the current batch. Closing that modal returns to the opening table, not too far back in navigation.

### Opening rituals
- Short real interactions with the object: foil drag tears the actual seam, key inserts/turns into a chest, directional command deploys a pod, dispatch mechanism for couriers, moonlit mechanism for its world. Do not copy the example literally to all worlds.
- The user liked Clockwork's ingenious dispatch-machine direction and later box animation. Preserve successful inventiveness.
- Manual and autoplay use the same meaningful animation path. Skip/autoplay has a button and shortcut. First two visits normal speed; third offers accelerated playback with opt-out and a later setting. Exact speed is provisional.
- Original bugs: duplicate keys, missing/clunky key turn, broken foil hit targets, two controls doing indistinguishable jobs, box showing wrong universe. Retest these when related handlers change.
- Effects scale with rarity and world; legendary should be an actual reveal moment, not only a different border. Next deliberately plays faster than the ceremonial reveal.
- Reduced motion and sound preferences remain. No audio files/paid runtime required for the synthesized current cues.

### Profile, showcase and community
- My showcase/collector room should be easy to reach. Navigation highlight follows current destination; it must not stick forever.
- Lounge begins with the user's own showcase, comments below, then discovering others, best pulls and leaderboards. Social data is fictional/local.
- Showcase slots should open an inline chooser: owned universes → owned cards → select, without dumping the user into binder navigation.
- Showcase supports drag ordering and keyboard/button alternatives. Neighbours respond gradually more as the held card approaches and return if it retreats. User described a magnetic/forcefield feeling: hesitant, fluid, noticeable, not an instantaneous jump. Recent stronger movement was desired.
- Unlike latest binder swap, showcase still uses insertion unless user changes that decision. Keep this distinction clear.
- Stationary click on showcase card must open detail. Dragging must not open detail, and credit clicks must still go to artist.
- Profile atmospheres, game favourites, Steam link and previews exist. Favourite games are fixed-size small boxes side-by-side, not cards that resize with quantity. Show game art; link to associated collection if it exists. Don't imply a Steam API/account connection from a manually entered URL.
- Visiting another collector should open their room/profile, not the current user's showcase. Completed-world honours/icons were praised.
- Watch together/spectator is local BroadcastChannel-based, not a live network multiplayer/social backend.

### Print and merchandise
- Printing only from owned available entitlements. Exact digital ownership is preserved under the current entitlement model while print history/consumption is tracked.
- Nine-pocket, multipage print planning and drag positioning exist. Combined print/merch parcel uses one simulated shipping estimate.
- Equal format/finish unit price regardless of card rarity. Premium physical products could cost differently, but business values await balancing.
- Merchandise should be rendered as believable products—binder, mat, sleeve, pin—not empty placeholders. Print & merch direction was positively received.
- No actual address collection, payments, shipments, commercial stock, tracking provider or real seller relationship is connected.

### Workshop, maintenance and safeguards
- Configurable rules/content and export/import exist. Prefer stable IDs and additive migrations.
- Malformed saves should not be overwritten; import validates and confirms replacement. Preserve old/custom catalog content.
- Help/onboarding/search/news/settings are implemented conveniences. Remove excessive repeated instructional prose as the final interface becomes self-evident, but keep accessible labels and non-obvious controls understandable.
- A dedicated mobile composition pass is deferred by user preference. Do not claim resizing desktop to a phone is final mobile design.

## 7. Exact normal opening interaction contract

This is the most regression-sensitive feature. Read the source history rather than guessing from the word “tilt.”

1. Draw outcomes are committed before animations. Animation skip/reload must not lose paid cards or grant extra copies.
2. Present a single offset pile of five cards (plus a cosmetic sixth if applicable). Small uneven offsets show physical depth; lower cards expose their backs, never unrevealed fronts.
3. Only the top card is interactive. First top card starts hidden. Dragging a hidden card moves it but **does not reveal or file it**. A deliberate stationary click or Reveal/Space flips it.
4. After that, a stationary click or Next sends the visible top card to the right and reveals the next. Do not require a second face-down flip for every card. Higher rarities sort toward the end while preserving actual outcomes and equal-rarity order. Multiple legendaries occupy the last positions.
5. During dragging, the card translates fluidly and leans/bends in the drag direction. This is not the pack-preview orbit effect. Current normal visible-card drag uses Y tilt up to 19 degrees, X up to 12, in-plane Z up to 8. These are implementation parameters, not eternal art direction. User likes the recovered original movement; keep it unless real testing calls for adjustment.
6. Remain within the agreed table bounds, with a slightly higher upper travel limit after Edition 15. Bounds must be calculated from stable geometry so transformed corners don't cause feedback jitter. Don't replace fluid movement with rigid translation to achieve bounds.
7. As the card approaches the right filing region, show a clear guide early enough to anticipate the drop. **Entering the zone is not filing. Releasing there files.** Releasing elsewhere springs home; pointer cancellation does not file or reveal.
8. Right-hand cards stack top-to-bottom in tidy stable slots. New arrival animates once. Do not rebuild/reanimate prior cards or flicker the box.
9. Clicking Next uses faster animation. Prevent rapid input from double-filing or double-charging. Unlock controls reliably when an animation is finished/cancelled.
10. Reveal, Next and Another pack share the exact same vertical action anchor. Face-down backs, face-up fronts, rarity effects and completion must not move it. Completion panel is card-sized and centred. Secondary completion choices sit below the primary button and disappear when a new pack begins.
11. Entry scroll puts the full table into the viewport while letting the global currency/back bar sit just above view; user can scroll a little up or use sidebar/bottom actions. This supersedes earlier “never scroll” demands. Do not make the whole screen cramped simply to retain the global bar.
12. Retest regular mouse click, tiny pointer jitter, intentional drag, reverse direction, corners, off-zone release, in-zone release, keyboard, reduced motion, last card, cosmetic last card and batch completion.

## 8. Design Lab contract and current Edition 15 behaviour

The Lab exists because final table design is undecided. It is a safe comparison area, not a production redesign applied without approval. Only Dungeon and Moonlit receive elaborate current scenes. Existing v13 paintings include a foreground desk and beautiful environment. At rest, the stack lies on that desk; manual/button pickup raises it to eye-level/centre. It stays raised on release. Pickup is not first reveal.

Once picked up, the user requested the same original normal opening behaviour: top-only drag, explicit first reveal, subsequent faces shown, bounded fluid movement, Next flight into right pull slots. Edition 15 moves toward that by using the normal card/back/pull-slot markup and common filing-zone geometry, but a separate Lab state/animation controller still exists. Do not falsely describe it as literally the identical complete controller. This remaining divergence is a useful refactor candidate once verified. Tests use DOM stubs and cannot certify 1:1 feel.

Current architecture choices: Open scene, Original table, Carved vault/Celestial window, Keeper's alcove/Moon garden pavilion. Rejected old Display cabinet/Collector's desk/Classic frame controls were removed; their old CSS remains historically in the cascade. Architecture is code-made SVG/CSS over the two existing paintings, not new commissioned art. User has not approved Edition 15 aesthetics yet.

Twelve detail layers: frame, foreground objects, glass panel, ambient light, motes, table inlay, side drapes, hanging lights, low mist, starfield, inscribed trim, display ledge. Latest user repeatedly reported being able to use only one at a time even though previous state tests passed. Edition 15 replaces buttons with native checkboxes and updates the scene incrementally without rerendering the controls. Multi-selection across architecture changes and saving is tested; actual browser composition still requires checking. Open scene must permit detail layers.

Physical receiver box below the right pull list is a Lab experiment. The animation currently targets a pull slot; a fully convincing “enters physical box then appears in list” sequence is not verified/final. Don't hide this gap if user asks.

Balanced is the selected motion preference; calm/lively remain comparison controls. Material studies are approved direction: sleeve inside card hierarchy, moving with the card, light/material effect not only static border. Saved combinations use a separate localStorage key and do not change normal room/inventory settings. No sample should award real demo inventory or consume credits.

## 9. Current checkpoint: completed versus awaiting review

Edition 15 code changes:
- Pairwise binder swaps and corresponding two-item preview.
- Absolute stage action anchoring rather than grid-only positioning.
- Another 16 pixels upper card travel.
- Singular “1 new card.”
- Explicit stationary showcase pointer-release opening of details.
- Native Lab checkboxes, in-place scene updates, combinations retained through architecture switches.
- Revised Lab stack/slots, pickup, face-up continuation, release geometry and filing animation.
- Replaced architecture options and perspective/material adjustments; physical receiver.

All 76 automated checks passed at snapshot. Latest full suite runtime was about 20 seconds. They include domain tests and one broad DOM-stub flow. The source was published successfully. **No real browser QA was possible in the old managed environment.** The user's annotations repeatedly revealed things those tests missed. Do not treat “76 passed” as evidence the Reveal button is now correctly placed in pixels, the details truly overlay correctly, or the motion is aesthetically right.

The next agent's first value should be reproducing the actual UI and checking these repairs. Do not jump directly to a massive new redesign and conceal these unresolved visual checks. Preserve the user-approved portions and compare the new browser result with the supplied descriptions.

## 10. Technical architecture and risk map

Buildless browser ES modules, HTML/CSS and localStorage. No package dependencies are required to run. `dist` is both source delivery directory and static output. `package.json` contains the Node test command. Serve over HTTP, not file://.

Key modules:
- `core.js`: state/accounting/validation and transactional operations.
- `catalog.js`, `edition-two.js`, `orbital.js`, `worlds-seven.js`: original and added content; stable collection/card IDs.
- `migration.js`, `experience-validation.js`: migration/validation; preserve custom text, ownership and archived content.
- `experience.js`: collecting/profile/queue/print/cosmetic logic.
- `collector-hub.js`: goals, journal, memories, milestone/table/room/print-planner state.
- `collector-custom.js`: colours/customization/extras.
- `community.js`: fictional community/game directory/guestbook logic.
- `presentation.js`, `presentation-dom.js`: sorted presentation and stable DOM updates.
- `opening.js`, `effects.js`: rituals/preferences/sound/reduced motion.
- `app.js`: main renderer, dialogs, event handlers and pointer lifecycle. Dense and increasingly large; use exact function scopes, not broad blind substitutions.
- `collector-views.js`, `views.js`, `workshop-view.js`: other page rendering.
- `edition-ten.js`: pagination, ordering geometry, binder/product/world object helpers.
- `edition-eleven.js`: fluid bounds, filing-zone geometry, original yielding and world frame.
- `edition-fourteen.js`: detail options and vacancy-chain preview for showcase insertion.
- `edition-fifteen.js`: pairwise binder swaps and scene architecture.
- `spectator.html/js`: same-origin local spectator channel.

CSS is accumulated: styles.css then edition-six through edition-fifteen. Later overrides and !important declarations are numerous. The same selector appears in several generations. Browser computed styles are essential when fixing layout. Do not assume a late rule wins without specificity/media checks. Refactor into shared scoped components incrementally only with before/after browser checks; do not wholesale rewrite during a bug fix.

Important current functions to inspect: `revealView`, `stageHTML`, `openingControls`, `renderStackLocal`, `advance`, `animateReveal`, `fileDraggedCard`, `pointerPaint`, `releasePhysical`, `springHome`, `prepareReorder`, `previewReorder`, `finishReorder`, `focusOpeningTable`, `designLab`, `labTableMarkup`, `labAdvance`, `previewDocument`, `showDetail`, `snapshot`, `back`.

Interaction risks:
- pointerdown.preventDefault can prevent native synthetic clicks; tests that dispatch only a click cannot reveal that.
- Bounds corrections must not count as user drag travel. Raw pointer distance is tracked separately; a stationary tap still reveals even if layout bounds would translate the card.
- Nested data-gesture elements must resolve to the intended top-level card, not only the back image.
- pointer capture and transformed geometry can feed back if remeasured incorrectly.
- suppressClick timing can swallow unrelated actions or allow duplicate dispatch. Preserve deliberate tap handling and test real events.
- Animations can finish after navigation/reset; guard old completion callbacks. Edition15 adds a Lab revision guard for world/reset; audit other state-changing Lab actions for stale callbacks if encountered.
- DOM rebuilding can replay arrivals, reset focus or interfere with a held pointer. Keep previously filed normal rail nodes stable.
- Fixed dimensions from multiple CSS generations can cause first face/back differences.
- Rarity/sleeve transforms must follow the same card hierarchy without clipping or detached overlays.

## 11. Persistence and migration

Main localStorage key is `card-atlas-v1`; it includes catalog/state export. Other keys include opening preferences (`card-atlas-opening`), effect preferences (see effects.js), and isolated Lab mix/favourite keys. The generated inventory lists exact strings found in the snapshot. Export/import is the supported portable collection backup; not every isolated browser setting is necessarily in the main export. Do not claim the ZIP includes the user's current collection.

Hosted Site origin and localhost origin have separate localStorage. Ports matter too. Opening localhost will initially show fresh demo state. Export on the hosted site, then import locally after validation; retain the backup. Never replace the live browser save just to take a screenshot. Use a separate browser profile/session or a copied save for QA.

Preserve exact quantities, printable entitlements, queued orders, protected cards, pending packs, current reveal, balances, rules, preferences, favourite folders, skins, tables, profile/showcase, journal/memories and archived cards. Content migrations should append/upsert carefully and retain user customization. Outcomes are committed before presentation, not on each animation frame.

## 12. Art assets, history and absent material

All tracked assets used by the source are included. `dist/assets` has edition directories. Existing docs/ART_ASSETS_* explain generation/provenance. Current v13 Lab paintings and v11 backs are present. Art remains original demo/concept work; fictional studio credits are not verified real artist commissions. Some older code-generated SVG art may still be used as fallback. Do not claim all final art is done.

The user has two other chats preparing large art-direction folders and later may provide hundreds of reference images. Those folders are not silently accessible and are not included here. A future art pass should use supplied approved references, not assume rejected experiments as canon. Art direction can change by world while card readability/shape/metadata remain consistent.

All available Git commits are included in source-history.bundle. Of particular interest, commit prefix `09d685a` was used as reference for earlier fluid drag feel. Inspect it in a separate worktree/clone and compare the relevant functions. Do not reset the whole app to recover one interaction. Edition13 `947f800...` fixed raw-motion tap classification; Edition14 `acad180...` introduced vacancy chains and control refactor; Edition15 is current. Earlier edition claims are history, not proof of present quality.

The conversation's screenshot filenames were reused across many batches, and many earlier uploads were absent at the time. This ZIP does not pretend to reconstruct an exact numbered screenshot archive. The latest screenshots were inspectable in the old session, but screenshots are not required for the source transfer. Textual annotation requirements are retained extensively. The original chat remains the authoritative conversational reference where available.

## 13. Recommended first session for the new agent

1. Read this handoff and the annotation chronology. Summarize only unresolved ambiguities, not everything the user already explained.
2. Run the existing tests from the extracted folder. Start the local HTTP site using allowed tooling. Verify the actual browser is available before promising visual validation.
3. Use a safe demo/test save. Verify card click/drag, fixed controls, pairwise binder swaps, stationary showcase detail, checkbox combinations and Lab sequence at 1304×884 and 1944×1244, the sizes used in feedback.
4. Check computed styles and pointer event delivery for any remaining bugs. Capture before/after evidence if supported. Preserve the normal site while adjusting Lab.
5. Check same Site deployment access separately. A working local folder is not authenticated publication access.
6. Present a concise readiness note: what transferred, what works, what you could visually verify and any remaining issue. Then continue user-authorized work.

## 14. What not to do

Do not make this into a gameplay TCG. Do not rename IDs to English. Do not delete archived sets. Do not overwrite browser saves. Do not silently switch binder swapping back to insertion. Do not reveal hidden cards just because dragged. Do not auto-file merely on entering a region. Do not add a flip click for every next card. Do not confuse pack rotation with card handling. Do not allow click suppression to disable card inspection. Do not claim all details mix just because a string test passed. Do not promote Lab experiments to production without a chosen direction. Do not leave product merchandise as empty placeholders while polishing only the hero. Do not equate prettier background with an in-world interface. Do not claim real partners/Steam/social/payments. Do not carry irrelevant personal sensitive data into project notes. Do not pretend a context handoff is literally the same running chat.

## 15. Completion standard

The aspiration is a beautiful, coherent, complete-feeling proof of concept. “Perfect” is the user's ambition, not a verifiable boolean. Deliver concrete improvements and accurately state limits. A good continuation makes the user repeat less, not more; safeguards earlier approvals; and uses actual browser evidence to prevent the regression cycle that caused frustration.
