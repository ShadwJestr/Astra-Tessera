# Technical inventory — generated from Edition 15

This inventory describes files present in the transfer, not a certification that each path is visually finished.

## Source checkpoint

```text
a54106f 2026-10-11T11:30:44+02:00 Update Site source
acad180 2026-10-10T16:22:02-07:00 Update Site source
947f800 2026-10-10T15:43:58-07:00 Update Site source
7af9dc9 2026-10-10T15:09:14-07:00 Update Site source
fb7fa74 2026-10-10T14:30:05-07:00 Update Site source
cdc1e26 2026-10-10T13:40:00-07:00 Update Site source
d747dc0 2026-10-10T12:51:00-07:00 Update Site source
8922343 2026-10-10T12:20:31-07:00 Update Site source
99ccb63 2026-10-10T11:44:38-07:00 Update Site source
09d685a 2026-10-10T11:06:57-07:00 Update Site source
459a611 2026-10-10T10:00:24-07:00 Update Site source
33ffde6 2026-10-10T08:44:44-07:00 Update Site source
fa6707d 2026-10-10T05:29:41-07:00 Update Site source
88ab65b 2026-10-10T04:56:16-07:00 Update Site source
65fa775 2026-10-09T22:40:34+02:00 Update Site source
```

## Runtime

Buildless HTML/ES modules. No package dependencies. Serve dist over HTTP. Tests require Node.js. Source snapshot was tested with v24.19.0.

## Module exports and internal function map

### app.js

Functions: `art`, `hero`, `card`, `folderIds`, `folderHTML`, `packHTML`, `toast`, `save`, `commit`, `snapshot`, `navigate`, `back`, `download`, `openModal`, `modalHead`, `render`, `updateScrollControl`, `packsView`, `BONUS_TEXT`, `revealItems`, `backCard`, `cosmeticCard`, `revealView`, `openingControls`, `stageHTML`, `railSlot`, `renderStackLocal`, `advance`, `trueIfRemaining`, `animateReveal`, `skipReveal`, `insufficient`, `purchase`, `startNext`, `beginRitual`, `renderRitual`, `ritualInput`, `updateRitualProgress`, `autoplay`, `cinematic`, `completeRitual`, `showDetail`, `recycleDesk`, `reviewRecycle`, `lastRecycleWarning`, `chooseFolders`, `missing`, `openingSettings`, `secureRandom`, `mutateCatalog`, `nextId`, `onClick`, `person`, `applyRecycle`, `currentBoxSize`, `nextPackButton`, `repeatCount`, `queueAutoNext`, `bundleHTML`, `boxHTML`, `spaceArt`, `scheduleCarousel`, `showcaseMini`, `showcasePicker`, `profileStyle`, `customize`, `previewDocument`, `fitPreview`, `foilAt`, `pointerPaint`, `releasePhysical`, `springHome`, `packArt`, `arrowIcon`, `showcasePopup`, `binderArt`, `showcaseGallery`, `gameTiles`, `completionBadges`, `loungeView`, `fileDraggedCard`, `cardMemoryHTML`, `tablePicker`, `roomSettings`, `printPicker`, `searchResults`, `designReview`, `help`, `handleEdition9`, `watchParty`, `launchSpectator`, `broadcastOpening`, `exportCollectorImage`, `prepareReorder`, `previewReorder`, `clearReorder`, `finishReorder`, `pagedCards`, `shelfSettings`, `packInformation`, `handleEdition10`, `scheduleParallax`, `focusOpeningTable`, `designLab`, `handleEdition12`, `visitorProfile`, `labExtras`, `labSleevedCard`, `labAdvance`, `labTableMarkup`, `handleEdition13`.


### art.js

Functions: `cardHighlight`, `drawing`, `artwork`.
Exported values/classes: `escape`.


### card-art-v6.js

Exported values/classes: `CARD_ART`, `PACK_ART`, `SPACE_ART`.


### catalog.js

Exported values/classes: `RARITIES`, `DEFAULT_RULES`, `ARTISTS`, `COLLECTIONS`, `CARDS`, `DEFAULT_CATALOG`.


### collector-custom.js

Functions: `extras`, `validateCustom`, `customizeState`, `defaultColors`, `colorStyle`.
Exported values/classes: `COLOR_PARTS`, `BASE_COLORS`.


### collector-hub.js

Functions: `hub`, `ensureHub`, `tableInfo`, `milestoneRows`, `trackChanges`, `bootstrapHub`, `toggleGoal`, `claimMilestone`, `chooseTable`, `setRoom`, `setShelf`, `setNote`, `completion`, `setPrintSlot`, `movePrintSlot`, `printPlanCounts`, `clearPrintPlan`, `finishOnboarding`, `validateHub`.
Exported values/classes: `WORLD_IDS`, `WORLD_DESIGN`.


### collector-views.js

Functions: `collectorView`, `printPlanner`, `onboarding`.


### community.js

Functions: `resolveGame`, `addGuestbookEntry`, `deleteGuestbookEntry`, `collectionMilestones`.
Exported values/classes: `GAME_DIRECTORY`, `normalizeGame`.


### core.js

Functions: `validateCatalog`, `newState`, `validateState`, `log`, `transaction`, `random`, `pick`, `rarityRoll`, `packAvailability`, `openPack`, `refill`, `craft`, `recyclable`, `recycle`, `recycleAll`, `printable`, `setCart`, `quote`, `placeOrder`, `importSave`, `exportSave`, `updateCatalog`, `binderFolders`, `setBinderFolder`.


### drag-geometry.js

Functions: `overPulls`.


### edition-eleven.js

Functions: `yieldingOffset`, `filingZone`, `softBound`, `fluidBounds`, `worldFrame`.


### edition-fifteen.js

Functions: `swapOrder`, `swapOffsets`, `scenePortal`.


### edition-fourteen.js

Functions: `vacancyOffsets`.
Exported values/classes: `LAB_DETAILS`.


### edition-ten.js

Functions: `pageColumns`, `pageSlice`, `boundedDrag`, `insertOrder`, `nearestSlot`, `shiftSlots`, `binderProduct`, `worldObjects`, `merchArtwork`.
Exported values/classes: `COSMETIC_DUPLICATE_FRAGMENTS`.


### edition-three.js

Exported values/classes: `RARITIES`, `DEFAULT_RULES`, `ARTISTS`, `COLLECTIONS`, `CARDS`, `DEFAULT_CATALOG`.


### edition-two.js

Exported values/classes: `RARITIES`, `DEFAULT_RULES`, `ARTISTS`, `COLLECTIONS`, `CARDS`, `DEFAULT_CATALOG`.


### effects.js

Functions: `loadEffects`, `saveEffects`, `effectiveMotion`, `effectTier`, `particleHTML`, `primeAudio`, `playCue`.


### experience-validation.js

Functions: `validateExperience`, `list`, `pack`.


### experience.js

Functions: `defaults`, `prepare`, `transaction`, `toggleList`, `selectedSets`, `collectionStats`, `purchasePacks`, `takePack`, `markOpened`, `setReveal`, `finishPack`, `changeLayout`, `setSkin`, `moveFolder`, `updateProfile`, `toggleShowcase`, `postCard`, `recyclePreview`, `recycleSelection`, `setMerch`, `parcelQuote`, `placeParcel`, `prioritizeBatch`, `finishBatch`, `moveShowcase`.
Exported values/classes: `BONUS_CHANCE`, `SKINS`, `MERCH`, `PEOPLE`.


### legacy-art.js

Functions: `artwork`.
Exported values/classes: `escape`.


### legacy.js

Exported values/classes: `RARITIES`, `DEFAULT_RULES`, `ARTISTS`, `COLLECTIONS`, `CARDS`, `DEFAULT_CATALOG`.


### migration.js

Functions: `upgradeContent`.


### opening.js

Functions: `loadOpeningPrefs`, `saveOpeningPrefs`, `openingTheme`, `openingStep`, `openingTarget`, `openingDuration`, `openingVisual`.
Exported values/classes: `COMMAND`, `ARROWS`.


### orbital.js

Exported values/classes: `ORBITAL_ARTIST`, `ORBITAL_SET`, `ORBITAL_CARDS`.


### premium-art.js

Exported values/classes: `HERO_ART`, `PREMIUM_ART`.


### presentation-dom.js

Functions: `updateRevealDOM`.


### presentation.js

Functions: `sortPullsForReveal`, `createReveal`, `advanceReveal`, `revealComplete`.


### scene-art.js

Functions: `scene`, `props`, `orbitalDrawing`.


### spectator.js



### views.js

Functions: `viewHTML`.


### workshop-view.js

Functions: `legacyView`, `numberField`, `workshop`, `plan`.


### worlds-seven.js

Exported values/classes: `NEW_SETS`, `NEW_ARTISTS`, `NEW_CARDS`, `NEW_CARD_ART`.


## UI action identifiers

Search these in app.js to locate dispatch behaviour. Not all are visible in every state.

`advance-fast`, `archive`, `art-inspect`, `artist`, `artist-binder`, `auto-next`, `autoplay`, `back`, `binder`, `binder-cover`, `card`, `card-page`, `carousel-pause`, `cart-delta`, `choose-folders`, `choose-speed`, `claim-milestone`, `clear-filters`, `clear-print-plan`, `close-modal`, `collection-binder`, `confirm-clear-plan`, `confirm-import`, `confirm-parcel`, `confirm-print-plan`, `confirm-recycle`, `confirm-reset`, `craft-card`, `credits`, `customize`, `damaged`, `delete-comment`, `design-review`, `dismiss-welcome`, `edit-catalog`, `edit-profile`, `export`, `export-catalog`, `export-print-proof`, `export-showcase`, `favourite`, `final-recycle`, `folder-move`, `folder-options`, `follow`, `game-pick`, `global-search`, `goal-craft`, `goal-wish`, `goal-world`, `help`, `import`, `inspect-pack`, `lab-advance`, `lab-favourite`, `lab-load-mix`, `lab-motion`, `lab-replay`, `lab-reset`, `lab-save-mix`, `lab-sleeve`, `lab-toggle`, `lab-variant`, `lab-world`, `launch-spectator`, `layout`, `leave-table`, `like`, `lock`, `lounge-tab`, `merch-add`, `merch-delta`, `merch-detail`, `merch-filter`, `missing`, `missing-folder`, `nav`, `new-post`, `news`, `next-pack`, `open-all-batch`, `open-folder`, `opening-input`, `opening-settings`, `opening-speed`, `pack-count`, `pack-information`, `packs`, `parcel-scroll`, `person`, `pick-card`, `pick-print-card`, `pick-universe`, `pin-goal`, `place-parcel`, `preview-device`, `preview-page`, `print-move`, `print-page`, `print-picker`, `profile`, `profile-style`, `purchase`, `queue-card`, `recycle-all`, `recycle-card`, `recycle-desk`, `refill`, `refill-modal`, `remove-folder`, `remove-print-slot`, `repeat-purchase`, `reset`, `reset-inspect`, `resume`, `review-print-plan`, `room-arrangement`, `room-prop`, `room-settings`, `room-shelf`, `room-world`, `scroll-top`, `select-print-slot`, `set-skin`, `set-table`, `shelf-columns`, `shelf-toggle`, `show-goal`, `showcase`, `showcase-move`, `showcase-picker`, `showcase-popup`, `skip-opening`, `skip-reveal`, `slide`, `slide-next`, `slide-prev`, `slow-opening`, `table-picker`, `toggle-collection`, `toggle-folder`, `toggle-motion`, `toggle-sound`, `turn-key`, `universe`, `unseal-box`, `watch-party`, `wish`, `wishlist`

## Storage keys


- app.js: `astra-design-lab-favourite`, `astra-design-lab-mix`, `card-atlas-v1`

- opening.js: `card-atlas-opening`


## Test files and scenarios

### app-smoke.test.mjs

- Astra Tessera page rendering, box queue, artist credit, recycle warnings and combined parcel (DOM stubs, not browser QA)

### content-effects.test.mjs

- five collectible collections with 20 unique cards each
- all 100 cards have original humour text, roles and vector illustrations
- migration preserves credits, quantities, printed entitlements, cart, orders and custom content
- migration works for exported first-edition saves and does not reset user rules
- effects default to silent, respect reduced motion, and survive malformed preferences

### core.test.mjs

- default content and new save validate
- pack spends once, adds exactly packSize copies, leaves input unchanged
- insufficient funds, invalid RNG and paused collections leave state untouched
- duplicate protection selects a missing card within rolled rarity without altering rarity
- tenth missed pack gets rare in final slot and resets collection counter
- natural rare resets pity; no extra forced draw when pack already qualifies
- pity disabled does not guarantee rare
- print quantities never exceed ownership; quotes ignore rarity; digital copies persist
- print entitlements stay exhausted after another order
- recycling preserves one copy and printed or reserved quantities
- crafting handles affordability, disabled option, archived cards and owned cards
- save roundtrip includes custom catalog and print history
- malformed saves and out-of-range quantities rejected before use
- invalid rules and references rejected
- archiving preserves ownership, removes card from pack pool and prevents incompatible deletion
- collection is unavailable when a weighted rarity has no active card
- bulk simulation respects accounting and collection boundaries across 300 packs

### edition-eight.test.mjs

- favourite games use known art but only real catalogue matches link to collections
- comments round-trip older saves without touching ownership, print entitlements or queue
- collection milestones count distinct owned cards, never duplicate quantities

### edition-eleven.test.mjs

- neighbours yield continuously on approach and settle when moving away
- filing guide accepts card edge before pointer reaches tray, excluding leftward or off-table drags
- card movement remains continuous near boundaries without leaving its permitted area

### edition-fifteen.test.mjs

- binder swap exchanges only the selected pair, including different rows
- only target binder moves into the original vacancy
- scene architecture remains two-dimensional, world-specific and optional

### edition-fourteen.test.mjs

- reordering shifts the intervening chain into the vacancy in either direction
- preview grows smoothly and retreats without displacing unrelated slots
- vacancy chain works across rows
- detail controls have twelve unique independently saved identifiers

### edition-nine.test.mjs

- legacy collection memories are honestly undated and quantities are untouched
- new pulls have durable memories, while milestone claims never consume cards
- locked tables reject selection, and reward ownership survives recycling later
- bonus table collectibles use an extra slot without changing card quantities
- print planning obeys unprinted quantities, swaps slots and prunes consumed copies
- goals, notes and room preferences round-trip without corrupting ownership
- completion costs only missing cards and preserves distinct versus duplicate counts
- tray hit testing follows actual viewport positions after scroll and layout changes

### edition-seven.test.mjs

- new courier IDs cannot overwrite archived clockwork ownership or print entitlements
- both new worlds preserve quantities, isolated packs and bonus cover entitlements
- showcase ordering preserves exact members and rejects boundary moves without inventory changes
- new ritual identity and all expanded accents are accepted

### edition-ten.test.mjs

- cosmetic rewards advance within a batch, then recycle once without consuming cards
- milestone-owned room duplicates recycle, while a missing binder still unlocks first
- legacy queued cosmetics remain valid and never grant retrospective fragments
- room shelf choices persist but never remove collections, cards or printing rights
- page turns contain at most three rows with no lost or repeated cards at supported widths
- drag bounds exclude headings and outside edges but allow the right-hand tray
- reorder previews move intervening neighbours to the vacant slots without mutating order

### experience.test.mjs

- box purchase is atomic, charges once, persists every paid pack and its reveal position
- bonus cosmetic is extra to five cards and unlock survives export/import
- bulk recycle keeps last copies, locks, printed copies and print reservations
- last-copy recycling needs a second confirmation and clears a depleted showcase
- combined parcel charges one shipping estimate and consumes only queued print entitlements
- selected universe totals, personalisation and local social survive validation
- a new purchase keeps its universe first without losing older waiting packs
- six-part free colours and profile links survive save validation; unsafe URLs rejected
- legacy waiting packs get contiguous batch metadata without changing inventory

### folders-stack.test.mjs

- chosen franchise folders are saved, removable without deleting cards, and validated
- old saves infer owned franchise folders; pack opening and crafting add folders
- display sorting preserves exact pulls, draw order among equal rarities and inventory metadata
- first click flips; each following click parks one and reveals next; final click parks last
- single-card and ten-card packs finish with one flip plus one move per card
- English content migration translates shipped text, preserves custom edits and keeps same IDs

### opening.test.mjs

- orbital commands reset on wrong input and complete only in order
- opening preferences persist speed and separate franchise counts, reject malformed values
- edition 3 upgrades append third universe without changing customised existing content or quantities
- third universe has independent valid packs and adds its own binder folder

### presentation-dom.test.mjs

- filing replaces only the new slot, preserving previous card and rail nodes
- flip and timer updates do not replace any filed slot or replay arrivals


## CSS load order

Later selectors can override earlier ones; media/specificity/important must be inspected.


1. `styles.css`
2. `edition-six.css`
3. `edition-seven.css`
4. `edition-eight.css`
5. `edition-nine.css`
6. `edition-ten.css`
7. `edition-eleven.css`
8. `edition-twelve.css`
9. `edition-thirteen.css`
10. `edition-fourteen.css`
11. `edition-fifteen.css`


## Asset inventory

57 asset files. Full SHA-256 list in TRANSFER_MANIFEST.json.


### assets/v10

- `classic-binder.webp` — 124478 bytes
- `couriers-binder.webp` — 172990 bytes
- `couriers-desk-props.webp` — 68672 bytes
- `donjon-binder.webp` — 196236 bytes
- `donjon-desk-props.webp` — 48744 bytes
- `gallery.webp` — 199808 bytes
- `moonlit-binder.webp` — 146120 bytes
- `moonlit-desk-props.webp` — 88838 bytes
- `orbital-binder.webp` — 117354 bytes
- `orbital-desk-props.webp` — 88948 bytes
- `recrues-binder.webp` — 136938 bytes
- `recrues-desk-props.webp` — 100312 bytes
- `slate-binder.webp` — 68324 bytes
- `velvet-binder.webp` — 84700 bytes

### assets/v11

- `couriers-back.webp` — 161762 bytes
- `donjon-back.webp` — 171012 bytes
- `moonlit-back.webp` — 105272 bytes
- `orbital-back.webp` — 90720 bytes
- `recrues-back.webp` — 119548 bytes

### assets/v13

- `donjon-scene.webp` — 295912 bytes
- `moonlit-scene.webp` — 324668 bytes

### assets/v5

- `chaos-hero.webp` — 246198 bytes
- `cosmic-rubber-duck.webp` — 199490 bytes
- `dark-duck.webp` — 250240 bytes
- `dungeon-hero.webp` — 352324 bytes
- `last-brain-cell.webp` — 194192 bytes
- `orbital-hero.webp` — 280034 bytes

### assets/v6

- `binder.webp` — 423258 bytes
- `community.webp` — 292006 bytes
- `packs.webp` — 636344 bytes
- `printing.webp` — 381924 bytes
- `sheet0.webp` — 508694 bytes
- `sheet1.webp` — 476808 bytes
- `sheet2.webp` — 501332 bytes
- `sheet3.webp` — 565802 bytes
- `sheet4.webp` — 617280 bytes
- `sheet5.webp` — 612966 bytes

### assets/v7

- `binders.webp` — 623220 bytes
- `couriers-1.webp` — 632996 bytes
- `couriers-2.webp` — 637796 bytes
- `couriers-hero.webp` — 390500 bytes
- `discovery.webp` — 389468 bytes
- `moonlit-1.webp` — 600858 bytes
- `moonlit-2.webp` — 565210 bytes
- `moonlit-hero.webp` — 316244 bytes
- `packs.webp` — 618302 bytes

### assets/v8

- `arrivals.webp` — 353822 bytes
- `couriers-table.webp` — 358744 bytes
- `donjon-table.webp` — 245328 bytes
- `moonlit-table.webp` — 331470 bytes
- `orbital-table.webp` — 171538 bytes
- `recrues-table.webp` — 136714 bytes

### assets/v9

- `couriers-prestige.webp` — 478304 bytes
- `donjon-prestige.webp` — 250862 bytes
- `moonlit-prestige.webp` — 382522 bytes
- `orbital-prestige.webp` — 147210 bytes
- `recrues-prestige.webp` — 172352 bytes


## Publication and local runtime boundaries

.openai/hosting.json retains the existing private Site identity. It is not a credential. The new machine needs its own authenticated Sites access before publishing. source-history.bundle holds available source history; it does not hold remote authority or local browser saves.
