# Start here — Astra Tessera transfer

Prepared for Ravn, 11 October 2026. Current snapshot: Edition 15.

## For Ravn
1. Extract the entire ZIP to a normal folder on your PC (not inside the ZIP viewer).
2. In Codex, create/open a project pointing to the extracted **Astra-Tessera** folder.
3. Start a new chat and paste the contents of **PROMPT_FOR_NEW_CODEX.txt**.
4. Before using a local copy, use **Export** on the existing live site to download your collection save. Import that JSON into the local site if you want your current collection there. The source ZIP cannot contain the inventory stored in your browser.
5. Keep the old chat and original live site. Do not delete them as part of this transfer.

## Run locally
Requires Node.js for this included launch method. There is no npm install or build step.

Windows: double-click **START_LOCAL.bat**. Open http://localhost:8000.
Other systems: run `node tools/serve.mjs` from this folder.
Alternative with Python: `python -m http.server 8000 --directory dist`.

Do not double-click dist/index.html: ES modules need an HTTP server.
The server binds only to 127.0.0.1 and serves dist. Keep the terminal open while testing; Ctrl+C stops it.
If port 8000 is busy: `node tools/serve.mjs 8001`, then open http://localhost:8001. Changing port also changes the browser storage origin; import your save again if needed.

## What to read
- **handoff/HANDOFF.md**: current product/design/interaction contract, detailed feature map, risks, state and next work.
- **handoff/ANNOTATION_HISTORY.md**: extensive chronological user feedback, including reversals and positive approvals.
- **handoff/TECHNICAL_INVENTORY.md**: generated source/action/test/asset map, exact revision and storage keys.
- **handoff/HISTORICAL_PROJECT_DOCUMENTS.md**: collected previous design briefs, product plan and edition reviews. Historical claims do not override newer corrections.
- **docs/**: original individual documents, including art asset provenance notes.
- **handoff/ACCEPTANCE_CHECKLIST.md**: browser regression scenarios and feature-completeness checks.
- **handoff/TRANSFER_MANIFEST.json**: file sizes and SHA-256 hashes.

## Tests
Run `npm test` (or `node --test tests/*.test.mjs`). At the transfer source checkpoint, all 76 automated checks passed. The smoke test is a DOM stub, not real browser automation. It does not certify layout, animation feel, click delivery, pointer capture or CSS compositing.

## History recovery — optional for the coding agent
The ZIP contains current working files without .git and **source-history.bundle** containing the repository's complete available Git history. Do not overwrite current files to inspect an older version. A safe separate clone is:

`git clone source-history.bundle ../Astra-Tessera-History`

That clone contains source history up to the Edition 15 checkpoint. Transfer-specific handoff files are in this ZIP, not in the historical commits. The bundle contains repository objects/refs, not the old checkout's credentials, Git config or hooks.

## Publishing
This folder alone does not grant publication access. The existing private Site must be reused if an authenticated Sites connector can access it. Exact identity and current deployment are in the handoff. Otherwise continue locally and report that publication needs connecting; do not pretend a local preview updated the live site.

## Important boundaries
The website's features and assets are included. Your browser inventory, sign-ins, private tool credentials, running cloud chat, hidden instructions and absent art-reference folders are not. A new chat must read the documents; it does not automatically inherit the old conversation.
