import test from 'node:test';
import assert from 'node:assert/strict';
import {vacancyOffsets,LAB_DETAILS} from '../dist/edition-fourteen.js';
const rects=Array.from({length:4},(_,i)=>({left:i*300,top:0,width:280,height:400,right:i*300+280,bottom:400}));
test('reordering shifts the intervening chain into the vacancy in either direction',()=>{
 assert.deepEqual(vacancyOffsets(rects,0,2,600,0).map(p=>Math.round(p.x)),[0,-300,-300,0]);
 assert.deepEqual(vacancyOffsets(rects,3,1,-600,0).map(p=>Math.round(p.x)),[0,300,300,0]);
});
test('preview grows smoothly and retreats without displacing unrelated slots',()=>{
 const near=vacancyOffsets(rects,0,1,170,0),closer=vacancyOffsets(rects,0,1,250,0);
 assert.ok(near[1].x<0&&closer[1].x<near[1].x&&closer[1].x>-300);
 assert.equal(closer[2].x,0);assert.equal(closer[3].x,0);
 assert.ok(vacancyOffsets(rects,0,0,0,0).every(p=>p.x===0&&p.y===0));
});
test('vacancy chain works across rows',()=>{
 const grid=rects.map((r,i)=>({...r,left:i%2*300,top:Math.floor(i/2)*420}));
 const offsets=vacancyOffsets(grid,0,3,300,420);
 for(let i=1;i<4;i++){assert.equal(grid[i].left+offsets[i].x,grid[i-1].left);assert.equal(grid[i].top+offsets[i].y,grid[i-1].top);}
});
test('detail controls have twelve unique independently saved identifiers',()=>{assert.equal(LAB_DETAILS.length,12);assert.equal(new Set(LAB_DETAILS.map(([id])=>id)).size,12);});
