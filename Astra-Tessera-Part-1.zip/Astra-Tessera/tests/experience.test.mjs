import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_CATALOG as c} from '../dist/catalog.js';
import * as core from '../dist/core.js';
import * as ex from '../dist/experience.js';
const fresh=()=>ex.prepare(core.newState(c));
test('box purchase is atomic, charges once, persists every paid pack and its reveal position',()=>{
 const original=fresh();let s=ex.purchasePacks(original,c,'orbital',3,()=>.2).state;
 assert.equal(original.credits,1000);assert.equal(s.credits,700);assert.equal(s.experience.queue.length,3);assert.equal(Object.values(s.inventory).reduce((a,b)=>a+b,0),15);
 s=ex.takePack(s,c).state;s=ex.markOpened(s,c).state;s=ex.setReveal(s,c,2,true).state;
 const restored=core.importSave(core.exportSave(s,c)).state;assert.equal(restored.experience.queue.length,2);assert.equal(restored.experience.current.active,2);assert.equal(restored.experience.current.faceUp,true);
 assert.throws(()=>ex.purchasePacks(s,c,'orbital',10,()=>.2),/credits/);assert.equal(s.credits,700);assert.equal(s.experience.queue.length,2);
 assert.throws(()=>ex.purchasePacks(s,c,'orbital',1,()=>NaN));assert.equal(s.credits,700);
});
test('bonus cosmetic is extra to five cards and unlock survives export/import',()=>{
 let s=ex.purchasePacks(fresh(),c,'donjon',1,()=>0).state;assert.equal(s.experience.queue[0].pulls.length,5);assert.equal(s.experience.queue[0].bonus,'donjon');assert.ok(s.experience.unlocks.includes('donjon'));
 s=ex.setSkin(s,c,'donjon','donjon').state;assert.equal(core.importSave(core.exportSave(s,c)).state.experience.skins.donjon,'donjon');assert.throws(()=>ex.setSkin(s,c,'donjon','orbital'),/not unlocked/);
});
test('bulk recycle keeps last copies, locks, printed copies and print reservations',()=>{
 let s=fresh();s.inventory={'donjon-01':5,'donjon-02':1,'donjon-03':3,'donjon-19':2};s.printed={'donjon-01':1};s.cart={'donjon-01':2};s=ex.toggleList(s,c,'locks','donjon-03').state;
 const preview=ex.recyclePreview(s,c,{rarity:'common'});assert.deepEqual(preview.items.map(a=>[a.cardId,a.quantity]),[['donjon-01',2]]);
 const next=ex.recycleSelection(s,c,preview.items,{confirmed:true}).state;assert.equal(next.inventory['donjon-01'],3);assert.equal(next.inventory['donjon-02'],1);assert.equal(next.inventory['donjon-03'],3);assert.equal(next.inventory['donjon-19'],2);
 assert.throws(()=>ex.recycleSelection(s,c,[{cardId:'donjon-01',quantity:3}],{confirmed:true,lastConfirmed:true}),/protected/);
 assert.throws(()=>ex.recycleSelection(s,c,[{cardId:'donjon-03',quantity:1}],{confirmed:true}),/protected/);
});
test('last-copy recycling needs a second confirmation and clears a depleted showcase',()=>{
 let s=fresh();s.inventory['orbital-19']=1;s=ex.toggleShowcase(s,c,'orbital-19').state;
 const p=ex.recyclePreview(s,c,{cardId:'orbital-19',rarity:'all',includeLast:true});assert.equal(p.last,true);assert.equal(p.valuable,true);
 assert.throws(()=>ex.recycleSelection(s,c,p.items),/Review/);assert.throws(()=>ex.recycleSelection(s,c,p.items,{confirmed:true}),/last owned/);
 s=ex.recycleSelection(s,c,p.items,{confirmed:true,lastConfirmed:true}).state;assert.equal(s.inventory['orbital-19'],0);assert.equal(s.fragments,c.rules.recycleValues.legendary);assert.deepEqual(s.experience.profile.showcase,[]);
});
test('combined parcel charges one shipping estimate and consumes only queued print entitlements',()=>{
 let s=fresh();s.inventory['donjon-01']=2;s=core.setCart(s,c,'donjon-01',1).state;s=ex.setMerch(s,c,'orbital-pin',2).state;
 const q=ex.parcelQuote(s,c);assert.equal(q.shipping,c.rules.shipping);assert.equal(q.total,14+c.rules.printUnit+c.rules.shipping);
 const result=ex.placeParcel(s,c);assert.equal(result.state.printed['donjon-01'],1);assert.equal(result.state.inventory['donjon-01'],2);assert.equal(result.state.experience.parcelOrders.length,1);assert.deepEqual(result.state.experience.merchCart,{});assert.deepEqual(result.state.cart,{});assert.equal(s.printed['donjon-01'],undefined);
});
test('selected universe totals, personalisation and local social survive validation',()=>{
 let s=fresh();s=ex.toggleList(s,c,'favourites','orbital').state;assert.ok(ex.selectedSets(s,c).includes('orbital'));assert.equal(ex.collectionStats(s,c,'orbital').missing,20);
 s=ex.changeLayout(s,c,'accent','mint').state;s=ex.updateProfile(s,c,'Ravn','Ducks and questionable decisions.').state;s.inventory['orbital-19']=1;s=ex.postCard(s,c,'orbital-19','The mission succeeded.').state;
 const saved=core.importSave(core.exportSave(s,c)).state;assert.equal(saved.experience.profile.name,'Ravn');assert.equal(saved.experience.layout.accent,'mint');assert.equal(saved.experience.posts.length,1);
 const bad=structuredClone(s);bad.experience.current={pack:{pulls:[]}};assert.throws(()=>core.validateState(bad,c));
});

test('a new purchase keeps its universe first without losing older waiting packs',()=>{
 let s=ex.purchasePacks(fresh(),c,'recrues',3,()=>.2).state;const old=s.experience.queue.map(p=>p.id);const bought=ex.purchasePacks(s,c,'donjon',3,()=>.2);s=ex.prioritizeBatch(bought.state,c,bought.packs.map(p=>p.id)).state;
 assert.equal(s.experience.queue[0].collectionId,'donjon');assert.equal(s.experience.queue.length,6);assert.deepEqual(s.experience.queue.slice(3).map(p=>p.id),old);
 s=ex.takePack(s,c).state;const done=ex.finishBatch(s,c);assert.equal(done.packs.length,3);assert.equal(done.state.experience.queue.length,3);assert.equal(done.state.experience.queue[0].collectionId,'recrues');assert.equal(Object.values(done.state.inventory).reduce((a,b)=>a+b,0),30);
});

test('six-part free colours and profile links survive save validation; unsafe URLs rejected',async()=>{
 const custom=await import('../dist/collector-custom.js');let s=fresh();s=custom.customizeState(s,'colors',['#112233','#223344','#334455','#445566','#556677','#667788'],'orbital').state;core.validateState(s,c);
 s=custom.customizeState(s,'profile',{banner:'orbital',games:['Titanfall 2','Portal 2'],steam:'https://steamcommunity.com/id/collector'}).state;assert.equal(core.importSave(core.exportSave(s,c)).state.experience.custom.profile.games.length,2);
 const bad=custom.customizeState(s,'profile',{banner:'orbital',games:[],steam:'javascript:alert(1)'}).state;assert.throws(()=>core.validateState(bad,c),/profile/);
 const badColor=custom.customizeState(s,'colors',['red'],'orbital').state;assert.throws(()=>core.validateState(badColor,c),/customisation/);
});

test('legacy waiting packs get contiguous batch metadata without changing inventory',()=>{
 let s=ex.purchasePacks(fresh(),c,'donjon',3,()=>.2).state;for(const p of s.experience.queue){delete p.batchId;delete p.batchSize;}const before=structuredClone(s.inventory);s=ex.prepare(s);assert.equal(s.experience.queue[0].batchId,s.experience.queue[2].batchId);assert.equal(s.experience.queue[0].batchSize,3);assert.deepEqual(s.inventory,before);core.validateState(s,c);
});
