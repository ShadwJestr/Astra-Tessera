import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_CATALOG as c} from '../dist/catalog.js';
import {DEFAULT_CATALOG as old} from '../dist/legacy.js';
import {upgradeContent} from '../dist/migration.js';
import * as core from '../dist/core.js';
import * as exp from '../dist/experience.js';
import {openingTheme,openingVisual} from '../dist/opening.js';
test('new courier IDs cannot overwrite archived clockwork ownership or print entitlements',()=>{
 const catalog=structuredClone(old),state=core.newState(catalog),card=catalog.cards.find(a=>a.collectionId==='clockwork');
 assert.ok(card);state.inventory[card.id]=3;state.printed[card.id]=1;state.cart[card.id]=1;
 const result=upgradeContent({format:'card-atlas-save-v1',catalog,state});
 assert.deepEqual(result.envelope.state,state);
 assert.equal(result.envelope.catalog.cards.filter(a=>a.collectionId==='couriers').length,20);
 assert.equal(result.envelope.catalog.cards.filter(a=>a.collectionId==='moonlit').length,20);
 assert.equal(result.envelope.catalog.collections.find(a=>a.id==='clockwork').active,false);
 assert.equal(result.envelope.catalog.cards.find(a=>a.id===card.id).name,card.name);
 assert.equal(upgradeContent(result.envelope).changed,false);
});
test('both new worlds preserve quantities, isolated packs and bonus cover entitlements',()=>{
 for(const id of ['couriers','moonlit']){
  const initial=exp.prepare(core.newState(c)),r=exp.purchasePacks(initial,c,id,3,()=>0);
  assert.equal(r.state.credits,700);assert.equal(Object.values(r.state.inventory).reduce((a,b)=>a+b,0),15);
  assert.ok(r.packs.every(p=>p.collectionId===id&&p.pulls.every(a=>a.cardId.startsWith(id+'-'))));
  assert.ok(r.state.experience.unlocks.includes(id));
  const dressed=exp.setSkin(r.state,c,id,id).state;core.validateState(dressed,c);
  assert.equal(core.importSave(core.exportSave(dressed,c)).state.experience.skins[id],id);
 }
});
test('showcase ordering preserves exact members and rejects boundary moves without inventory changes',()=>{
 let s=exp.prepare(core.newState(c));s.experience.profile.showcase=['recrues-01','donjon-01','orbital-01'];
 for(const id of s.experience.profile.showcase)s.inventory[id]=1;
 const r=exp.moveShowcase(s,c,'orbital-01',-1).state;
 assert.deepEqual(r.experience.profile.showcase,['recrues-01','orbital-01','donjon-01']);
 assert.deepEqual(r.inventory,s.inventory);
 assert.deepEqual(exp.moveShowcase(r,c,'recrues-01',-1).state.experience.profile.showcase,r.experience.profile.showcase);
 assert.deepEqual(s.experience.profile.showcase,['recrues-01','donjon-01','orbital-01']);
});
test('new ritual identity and all expanded accents are accepted',()=>{
 assert.equal(openingTheme('couriers'),'clockwork');assert.equal(openingTheme('moonlit'),'moonlit');
 assert.match(openingVisual('clockwork',1,5),/data-gesture="dial"/);assert.match(openingVisual('moonlit',1,5),/data-key="star-1"/);
 let s=exp.prepare(core.newState(c));for(const value of ['ocean','coral','ice','lime']){s=exp.changeLayout(s,c,'accent',value).state;core.validateState(s,c);assert.equal(s.experience.layout.accent,value);}
});
