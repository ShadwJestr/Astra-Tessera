import test from 'node:test';
import assert from 'node:assert/strict';
import {yieldingOffset,filingZone,fluidBounds} from '../dist/edition-eleven.js';
test('neighbours yield continuously on approach and settle when moving away',()=>{
 const held={left:0,top:0,width:200,height:280},neighbour={left:240,top:0,width:200,height:280};
 const far=yieldingOffset(neighbour,held,-100,0),near=yieldingOffset(neighbour,held,80,0),closer=yieldingOffset(neighbour,held,150,0);
 assert.equal(far.x,0);assert.ok(near.x>0);assert.ok(closer.x>near.x);assert.ok(closer.x<=85);assert.ok(closer.angle<=6);assert.deepEqual(yieldingOffset(neighbour,held,-100,0),far);
});
test('filing guide accepts card edge before pointer reaches tray, excluding leftward or off-table drags',()=>{
 const rect={left:100,top:100,width:200,height:280},rail={left:600,right:900,top:50,bottom:650};
 assert.equal(filingZone(rect,rail,265,0),true);assert.equal(filingZone(rect,rail,200,0),false);assert.equal(filingZone(rect,rail,-5,0),false);assert.equal(filingZone(rect,rail,265,900),false);
});
test('card movement remains continuous near boundaries without leaving its permitted area',()=>{
 const rect={left:200,right:400,top:150,bottom:430,width:200,height:280},area={left:0,right:1000,top:0,bottom:700};
 for(let dx=-500;dx<=1000;dx+=7){const p=fluidBounds(rect,area,dx,dx);assert.ok(rect.left+p.dx>=area.left);assert.ok(rect.right+p.dx<=area.right);assert.ok(rect.top+p.dy>=area.top);assert.ok(rect.bottom+p.dy<=area.bottom);}
 const a=fluidBounds(rect,area,580,0),b=fluidBounds(rect,area,590,0);assert.ok(b.dx>a.dx);assert.ok(b.dx-a.dx<10);assert.equal(fluidBounds(rect,area,0,0).dx,0);
});
