import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_CATALOG as catalog} from '../dist/catalog.js';
import * as core from '../dist/core.js';
import * as exp from '../dist/experience.js';
import {resolveGame,addGuestbookEntry,deleteGuestbookEntry,collectionMilestones} from '../dist/community.js';

test('favourite games use known art but only real catalogue matches link to collections',()=>{
 assert.equal(resolveGame('apex',catalog).name,'Apex Legends');
 assert.match(resolveGame('APEX',catalog).image,/1172470/);
 assert.equal(resolveGame('apex',catalog).setId,null);
 assert.equal(resolveGame('clockwork couriers',catalog).setId,'couriers');
 assert.equal(resolveGame('Unlisted game',catalog).image,null);
 const future=structuredClone(catalog);future.collections.push({id:'apex',name:'Apex Legends',active:true});
 assert.equal(resolveGame('apex',future).setId,'apex');
});
test('comments round-trip older saves without touching ownership, print entitlements or queue',()=>{
 const initial=exp.purchasePacks(exp.prepare(core.newState(catalog)),catalog,'couriers',3,()=>0).state;
 const next=addGuestbookEntry(initial,'  A superb delivery.  ').state;
 core.validateState(next,catalog);
 assert.deepEqual(next.inventory,initial.inventory);assert.deepEqual(next.experience.queue,initial.experience.queue);
 assert.equal(initial.experience.custom,undefined);
 const imported=core.importSave(core.exportSave(next,catalog)).state;
 assert.equal(imported.experience.custom.guestbook[0].text,'A superb delivery.');
 assert.equal(deleteGuestbookEntry(imported,imported.experience.custom.guestbook[0].id).state.experience.custom.guestbook.length,0);
 assert.throws(()=>addGuestbookEntry(initial,'  '));assert.throws(()=>addGuestbookEntry(initial,'a'.repeat(401)));
 const malformed=structuredClone(next);malformed.experience.custom.guestbook[0].text='a'.repeat(401);assert.throws(()=>core.validateState(malformed,catalog));
});
test('collection milestones count distinct owned cards, never duplicate quantities',()=>{
 const s=exp.prepare(core.newState(catalog));s.inventory['couriers-01']=25;
 assert.equal(collectionMilestones(s,catalog)[0].owned,1);assert.equal(collectionMilestones(s,catalog)[0].complete,false);
 for(const a of catalog.cards.filter(a=>a.collectionId==='couriers'))s.inventory[a.id]=1;
 assert.equal(collectionMilestones(s,catalog)[0].complete,true);
});
