import test from 'node:test';
import assert from 'node:assert/strict';
import {swapOrder,swapOffsets,scenePortal} from '../dist/edition-fifteen.js';
test('binder swap exchanges only the selected pair, including different rows',()=>{assert.deepEqual(swapOrder(['a','b','c','d','e','f'],0,3),['d','b','c','a','e','f']);assert.deepEqual(swapOrder(['a','b'],0,0),['a','b']);});
test('only target binder moves into the original vacancy',()=>{const r=[{left:0,top:0},{left:300,top:0},{left:0,top:400},{left:300,top:400}];const offsets=swapOffsets(r,0,2,0,400);assert.equal(offsets[2].y,-400);assert.deepEqual(offsets[1],{x:0,y:0,angle:0});assert.deepEqual(offsets[3],{x:0,y:0,angle:0});const partial=swapOffsets(r,0,2,0,230);assert.ok(partial[2].y<0&&partial[2].y>-400);});
test('scene architecture remains two-dimensional, world-specific and optional',()=>{assert.equal(scenePortal('donjon','panorama'),'');assert.match(scenePortal('donjon','portal'),/svg/);assert.notEqual(scenePortal('donjon','portal'),scenePortal('moonlit','portal'));assert.notEqual(scenePortal('donjon','pavilion'),scenePortal('donjon','portal'));});
