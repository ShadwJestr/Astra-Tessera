# Astra Tessera — mandatory project orientation

You are continuing an existing project for Ravn, formerly built by an agent called Rook. Do not rebuild from scratch or treat it as a generic card-game prompt.

Read START_HERE.md, then handoff/HANDOFF.md and handoff/ANNOTATION_HISTORY.md before making design or behaviour changes. handoff/TECHNICAL_INVENTORY.md maps the source. Existing docs/ files preserve historical decisions; later explicit user instructions supersede earlier ones. The handoff is an extensive reconstruction, not a verbatim export of the whole chat.

Critical rules:
- Preserve inventory, currencies, archived cards, pending packs, print reservations, journal and cosmetic unlocks. Never change stable IDs or reset saves to simplify an update.
- No real purchases, real fulfilment, production social service, official franchise partnership, or verified artist commission is connected. Keep simulations honest.
- Default to the user's current intent, not old conflicting annotations. Most recent binding examples: binders SWAP two positions; showcases retain progressive insertion; hidden card drag does not reveal; only release inside the file zone files; first click reveals and later clicks file/reveal in sequence; Reveal/Next/Another pack share a fixed anchor.
- Art and motion are central product requirements. Passing Node tests is not visual acceptance. Many earlier updates passed tests while real browser behaviours were broken.
- Reproduce reported UI problems in a real browser when your environment supports it. Test affected neighbours, including click versus drag, after a fix. Do not invent visual QA results.
- Keep bold experiments in Design Lab. Only two worlds currently receive elaborate Lab tests: Discount Dungeon and Moonlit Menagerie. Do not silently promote them to normal rooms.
- The user wants a 2D site that feels inside an IP world, not a navigable 3D game. Rich integrated surfaces, perspective, materials and artwork matter; generic translucent panels with a changed background do not meet the goal.
- Preserve approved card backs, sleeve materials, fluid handling and readable card foregrounds. Reduce regressions before adding features.
- Speak plainly and concisely. Be truthful about what is implemented, validated, provisional and blocked. Do not promise perfect output, guaranteed no bugs, exact full-context transfer, fixed hours of autonomous work, or access to unseen chats/reference folders.
- Work autonomously on authorized changes; ask only when necessary. Do not flood the user with repetitive confirmations. If asked to wait while they annotate, wait.
- Do not carry unrelated personal biography into product design. Relevant preferences are in the handoff.
- Before publishing, confirm same Site identity and audience through available Sites tools. Never create a replacement Site just because the hosted name differs from Astra Tessera. Never copy credentials into code or documents.

This transfer includes a clean source snapshot and a Git bundle. Import history if needed; no authentication tokens or local browser save are included.
