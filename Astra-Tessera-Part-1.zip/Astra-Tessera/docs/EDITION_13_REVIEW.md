# Edition 13 — Two worlds at the table

## Scope
Only two new high-detail scene artworks: Discount Dungeon and Moonlit Menagerie. Both are Lab-only studies, not replacements for normal opening rooms. Current franchise art references are still pending.

## Detailed experiments
- Dungeon: warm candlelit leather desk, carved duck ornaments and a cavern lake/castle beyond.
- Moonlit: indigo velvet/silver terrace table, flowers and a moonlit hotel landscape.
- The illustrated table is in the foreground. A sample stack starts resting on it, lifts to eye level, then can be revealed and filed to the right. It uses five sample cards without changing ownership, currency or progression.
- Independent toggles for frame, extra props, glass, ambient lighting and particles. Four architectural treatments retained as compositional options.
- Save and restore a combination using a separate Lab preference key. It does not apply to normal rooms.
- Sleeve studies now live inside the card element, following its tilt and movement. Added gilded sheen, leaf glow and holographic material lighting, rather than edge decoration alone.
- Larger hands-on motion area with calm/balanced/lively sideways-bend presets. Drag, pause, reverse and release to compare. Keyboard/button alternatives for the sample sequence.

## Repairs
- Pointer gesture detection now uses actual pointer travel. Previously, boundary correction could falsely classify a stationary click as a drag. Pointer release explicitly handles a tap once and suppresses its duplicate synthetic click.
- Stack, completion message and action controls have explicit centred grid positions. Existing working drag rotation retained.
- Removing card protection now animates the sleeve sliding off. Reduced-motion preference bypasses it.
- Neighbour yielding increased to 85px maximum with a restrained six-degree lean, still dependent on proximity.

## Verification
The full automated suite includes a regression case that places the card outside the available boundary, then performs a stationary pointer down/up and asserts one reveal without filing. Hidden-card dragging, release filing and saved inventory are still checked. Lab actions test lifting, revealing, filing, reset, detail toggles and save without collection mutation.

Art assets were visually inspected independently. Full browser rendering and subjective motion feel remain unverified because supported browser-control tooling is unavailable. This release does not claim final placement or tactile quality is approved.

## User review
- Does the seated foreground table and eye-level lift establish the desired connection between world and cards?
- Does removing the glass panel give enough clarity with the richer scenery?
- Which combination of framing, props, light and atmosphere feels best?
- Is neighbour movement strong enough now, without the immediate slot-jumping from earlier versions?
- Check stationary click, drag, return and completion centering together in the normal opening screen.

Decorative sleeves are still Lab materials, not a real reward/unlock system. Normal protected cards use the existing clear sleeve.
