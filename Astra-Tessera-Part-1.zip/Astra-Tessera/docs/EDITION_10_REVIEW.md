# Astra Tessera — Edition 10 review

2026-10-10. A substantial collecting-room and interaction pass, preserving the existing local collection and private site audience.

## What changed

- Original physical binder illustrations for the five worlds plus three basic covers; a purpose-made collector gallery; five transparent foreground prop arrangements. The opening environments combine scene art, foreground objects, furniture edges, materials and restrained parallax.
- Collection grids use album pages of at most three rows. This applies to franchise folders, universe catalogues, artist catalogues and wishlists. Filter changes reset the relevant page.
- Dragging a revealed card into the filing area shows a release guide. Only release commits the move. Dragging stays within the usable table and hidden cards remain hidden. Binder and showcase neighbours move aside during reorder previews; ownership/order saves only on release.
- Compact desktop opening layouts use available viewport space. Pack selection keeps purchase controls together; detailed odds and cosmetic rules are available in a dedicated panel.
- Repeat purchase remembers the previous quantity, including boxes, with a separate single-pack action.
- Cosmetic duplicates automatically become 40 fragments each. Per-pack processing means a batch can unlock a binder, then a room, then recycle subsequent duplicates. Existing queued rewards are not retroactively credited.
- Collector shelves can hide chosen binders and use three, four or five columns. Smaller physical covers allow more items per row.
- Card stories sit beneath the card, showcase controls expand in place, and protection has a more visible fitted sleeve animation.
- Merchandise uses physical product imagery, layered sleeves, stitched mats and matching concepts for the two newer worlds. The existing simulated print/merch flow remains intact.
- Customizer previews use the actual rendered page and device-specific pagination; new binder previews reflect their physical forms. Cover trim colours do not tint the illustration.
- Edition 10 appears in What's new. Reduced-motion preferences disable the new scene movement.

## Latest annotation checklist

| Batch / note | Disposition |
| --- | --- |
| A1 | Subtle slower background parallax with reduced-motion support; gallery art made for the collecting space. |
| A2–3 | Illustrated merch products and physical miniature binders. |
| A4 | Neighbour displacement while dragging binders or showcase cards. |
| A5 | Full mobile design pass remains a separate phase; responsive fallbacks retained. |
| A6 | Existing print and merch workflow preserved and visually improved. |
| A7–8 | Smaller binder objects, configurable shelf columns and visible-binder selection. |
| A9 | Reduced repeated interaction instructions; essential accessible labels retained. |
| A10 | Cross-site pass through collecting room, store, detail, cosmetics, previews and opening environments. |
| A11 | Three-row album pages across collection-oriented grids. |
| A12 | Story moved under the card to compact the detail layout. |
| A13 | Native expanding showcase section in card details. |
| A14 | Stronger sleeve entrance, sheen and protection badge. |
| A15 | What's new retained and updated for this edition. |
| B1 | Universe catalogues share the same pagination component as binders. |
| B2 / B8 | Layered foreground props and furniture/material treatments move rooms toward an in-world 2.5D scene. Final art-direction approval remains open. |
| B3 | Filing occurs on release; proximity shows an insertion guide only. |
| B4 | Full card bounds constrained to the usable table, excluding the heading. |
| B5–7 | Desktop opening scene sized against viewport with reduced margins and rail slots sized to pack contents. Requires visual browser verification at actual viewport sizes. |
| B9 | Store essentials compacted; secondary odds content moved to an explicit panel. |
| B10 | Room choices preview scene props and differentiated ornamental/prestige furniture treatments. They are not yet wholly separate 3D rooms. |
| B11 | Repeat original pack quantity / box with separate single-pack option. |
| B12 | Duplicate binder/room cosmetics convert to fragments automatically; shared reward presentation supports the same duplicate receipt. Future trinkets are not implemented yet. |
| B13 | Extra cosmetic chance remains visible, with full odds explanation accessible. |

## Decisions for Ravn to judge

1. **Room composition:** deliberately layered 2.5D, rather than a live 3D engine. Does the scale and placement of props feel like occupying the world? This needs your visual review. It is a substantial step, not a claim that the final environment is achieved.
2. **Binder colour customisation:** free colours currently affect the mounting/trim elements. The illustration keeps its authored colours. Independently recolouring six physical parts of an illustrated binder needs authored masks or modular artwork and remains unfinished.
3. **Cosmetic duplicates:** 40 fragments per duplicate is an explicit prototype economy choice, not a balanced production value.
4. **Prestige rooms:** richer trim/structure and scene props distinguish them, but fully bespoke prestige compositions and additional unlockable trinkets remain future work.
5. **Art quality:** new binder and prop assets have been inspected independently. The complete composition and every older card illustration have not been certified as final art. Do not treat this update as completion of all art direction.
6. **Mobile:** the dedicated phone interface redesign is still needed after desktop interaction and art direction settle.
7. **Scope:** this remains a local-state proof of concept. Community content, merchandise and checkout remain simulated; production accounts, server-backed inventory, real payments, shipping and moderation are not introduced here.

## Validation

- Full automated suite: 66 passing tests, including batch rewards, duplicate conversion, legacy queue compatibility, shelf preferences, pagination, bounded drag and reorder geometry.
- DOM-stub smoke tests verify release-only filing, neighbour movement before saved reorder, collection page changes, repeated pack quantity, odds panel, compact detail and news entry.
- DOM-stub tests do not prove browser rendering, animation smoothness or pixel-perfect viewport fit.
- The supported browser-control capability is unavailable in this managed environment. No substitute preview server or unsupported browser automation was used. A real desktop and phone browser pass remains outstanding.

Asset prompts and provenance: `docs/ART_ASSETS_V10.md`.
