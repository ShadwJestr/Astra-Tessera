# Edition 9 — prestige opening rooms

Five original widescreen backgrounds generated with the built-in imagegen tool, 10 October 2026. All source images were visually inspected and converted to WebP quality 88 using Sharp. All are 1672 × 941. No cropping or compositing, no reuse of card artwork. These are generated art assets, not commissioned final franchise artwork.

## Prompt set and assets

Shared direction: purpose-composed 16:9 collectible-site opening-room background, seated collector perspective across broad empty tabletop, calm central foreground for card UI, grand world architecture above and around it. No characters, cards, text, numbers or logos. Clean intentional shapes, varied illustrated styles rather than generic glossy noise.

- `dist/assets/v9/recrues-prestige.webp`: Chaos Crew neon tournament command booth, cel-shaded comic game style, angular violet/acid-green holographic rails, distant arena with floating blank geometric display panels. Broad matte midnight desk.
- `dist/assets/v9/donjon-prestige.webp`: Discount Dungeon dragon treasure vault, handpainted storybook gouache, stone columns shaped as folded dragon wings, gilded side alcoves, warm braziers and moss-green shadow. Broad dark carved-stone tabletop with gold scroll fittings at side edges.
- `dist/assets/v9/orbital-prestige.webp`: Orbital Oddjobs captain’s bridge, clean retro sci-fi concept illustration, panoramic ringed blue planet and fleet, circular tactical console, orange side fittings and teal rim lighting. Quiet blue-grey center surface.
- `dist/assets/v9/couriers-prestige.webp`: Clockwork Couriers observatory postal engine, architectural ink and paint, brass orrery, pneumatic tubes, teal arches and skybridges, outer brass drawer stacks. Broad dark teal leather postal desk.
- `dist/assets/v9/moonlit-prestige.webp`: Moonlit Menagerie floating greenhouse observatory, dreamy illustrated watercolor, glass dome, hanging gardens, enormous crescent moon and floating hotel towers. Deep indigo crescent-edged desk with pale floral edge filigree.

## Inspection notes

All five outputs keep the foreground unobstructed and provide stronger architectural world identity than the base rooms. Moonlit has more visible architecture and a slightly smaller clear tabletop fraction, but its central lower area remains available for UI. Integrated responsive cropping and contrast still require site-level verification; asset inspection alone does not prove the interface is release-ready.
