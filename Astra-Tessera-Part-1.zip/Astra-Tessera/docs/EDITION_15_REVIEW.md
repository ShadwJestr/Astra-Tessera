# Edition 15 — Interaction repairs and world frames

## Addressed feedback
1. Binder dragging swaps the held and targeted binder only. Intervening rows stay still. The progressive motion curve is preserved. Showcase insertion remains unchanged.
2–3. Reveal, Next and repeat-purchase controls are now absolutely anchored within a full-height stage, independent of card/back content. This supersedes the earlier grid-only repair.
4. Upper card travel increased by another 16 pixels; other boundaries retained.
5. Accurate opening-room previews remain a requirement for the final chosen scenes, deferred as requested.
6. Completion says “1 new card” and pluralizes other counts.
7. Lab stack uses the normal stage/back/card hierarchy and normal pull-slot renderer. After pickup: explicit first reveal, face-up continuation, bounded dragging, tray hit detection, release-only filing, rightward animated filing, Next, and reset. Hidden cards do not file. A receiver box sits below the pull panel. Normal collection state is untouched.
8–11. Rejected cabinet/desk/classic options removed. Open scene and Original table retained alongside world-specific carved/celestial portals and alcove/pavilion studies. Two-dimensional SVG architecture follows the existing illustrated scene. All twelve detail layers now have native checkboxes, checked-state feedback and incremental updates; changing one does not rebuild the controls. Open scene permits all layers. Fireflies and twinkling lights replace uniform dot patterns; trim/inlay/props perspective adjusted to the illustrated desk.
12. Stationary showcase pointer release explicitly opens card details, independent of a browser-generated click following prevented pointerdown. Dragging still reorders.

## Verification
76 automated checks passed (domain tests and DOM-stub interaction flow, not browser QA). New coverage: two-item binder swap across rows, unchanged unrelated slots, progressively animated swap offsets, stationary showcase tap, native checkbox multi-selection across architecture switches. Existing click/reveal, hidden drag, release-only filing, sample pickup, sample face-up continuation, save/restore, inventory and currency checks remain passing.
User screenshots were available and inspected, including the misplaced Reveal button. Supported browser automation is unavailable, so actual rendering, pointer feel, CSS compositing and visual quality are not certified by these tests.

## Still provisional
Architectural studies and the physical receiver are comparison concepts, not a final approved aesthetic. Final preview fidelity is deferred until the scene is chosen. Art reference folders and dedicated mobile redesign remain later phases. The supplied two scene paintings are retained; no new raster painting was needed for these structural variants.
