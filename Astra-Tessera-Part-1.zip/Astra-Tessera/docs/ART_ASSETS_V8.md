# Edition 8 — dedicated opening environments

Six original widescreen interface backgrounds generated with the built-in imagegen tool, 10 October 2026. All source images visually inspected and converted to WebP quality 88 using Sharp. All 1672 × 941. No cropping, compositing, or source-art reuse. Intended as decorative full-bleed backgrounds; layer UI above them. Tables intentionally keep their central/lower area clear. These are generated illustrations, not commissioned production artwork.

## Assets and prompt set

Shared table direction: seated collector perspective across a broad tabletop, central and lower 70% quiet space for cards and controls. World atmosphere visible at upper sides and corners. No foreground characters, cards, text or logos. Widescreen 16:9, clean shapes and purposeful art style rather than uniform glossy hyperdetail.

- `dist/assets/v8/recrues-table.webp`: Chaos Crew — bold cel-shaded violet/acidic-green gaming team workshop, angular acoustic panels, neon light bars, headphones and soda at side corners. Matte charcoal tabletop. Graphic confident shapes and restrained detail.
- `dist/assets/v8/donjon-table.webp`: Discount Dungeon — handpainted storybook gouache, broad brush shapes, candlelit stone-and-timber tavern, treasure chest and mushroom at upper corners, broad wooden tabletop. Amber/moss palette.
- `dist/assets/v8/orbital-table.webp`: Orbital Oddjobs — clean retro science-fiction concept illustration, spaceship panoramic docking-bay windows and ringed planet, tactical desk with blue-grey surface, orange hazard trim, teal strip lights. Purposeful simple industrial shapes.
- `dist/assets/v8/couriers-table.webp`: Clockwork Couriers — architectural ink and paint, brass/teal postal sorting desk, pneumatic tubes and envelopes at outer corners, clockwork-city bridges beyond windows. Broad dark-teal leather desktop with copper edging.
- `dist/assets/v8/moonlit-table.webp`: Moonlit Menagerie — dreamy illustrated watercolor, indigo/rose conservatory, moonlit garden windows and roses, porcelain teacup at outer corner. Broad empty indigo velvet table with sparse celestial corner decoration.
- `dist/assets/v8/arrivals.webp`: editorial announcement banner, two contrasting portal doorways on right 60%: copper clockwork postal city and indigo crescent magical hotel garden. Dark quiet left 40% for headline text. Ink-and-paint architectural treatment with readable forms and subtle light spill.

## Inspection

All five table images keep a clear central foreground and visually distinct materials/palettes. The announcement places both portals to the right with useful dark text space to the left. Generated background quality does not by itself establish the quality of the integrated UI; responsive crops and text contrast require interface validation.
