# Card Atlas v5 artwork provenance

Created 2026-10-10 with the built-in `image_gen.imagegen` tool. These are original AI-generated prototype assets, not commissioned artist work or official franchise imagery. The fictional artist names in the demo catalog must not be presented as real authors of these generated illustrations.

All six results were visually inspected. Heroes use a 16:9 composition with darker left-hand space for copy. Portraits use 2:3 composition and darker lower areas for text. Images have no intended lettering, card frame or UI. Original outputs are copied unchanged to `dist/assets/v5`; `dist/premium-art.js` supplies stable mappings.

| Asset | Catalog mapping | Visual intent |
| --- | --- | --- |
| chaos-hero.png | recrues | Purple gaming squad, unplugged controller, toaster repair, pigeon on headset |
| dungeon-hero.png | donjon | Mage with empty purse, overloaded goblin, knight in sandals, mimic chest |
| orbital-hero.png | orbital | Self-repairing robot, oversized delivery, cat piloting ship |
| last-brain-cell.png | recrues-20 | Exhausted brain on controller throne holding last idea |
| dark-duck.png | donjon-19 | Harmless yellow duck in intimidating crown and cape |
| cosmic-rubber-duck.png | orbital-19 | Golden bath duck, astronaut helmet, halo and soap bubbles |

## Generation prompts

### Chaos Crew hero

Use case: stylized-concept. Create a polished wide 16:9 game universe showcase illustration for an original collectible card universe called Chaos Crew. No lettering. An absurd but charismatic squad of three young adult gaming scavengers wearing improvised purple tactical streetwear in a neon-lit gaming den, one triumphantly holding a completely unplugged controller, one repairing a toaster as if it were critical military hardware, one distracted by a pigeon perched on their headset. Painterly premium game concept art, expressive believable faces, mature graphic-novel proportions, strong silhouette and composition, purple and restrained acid teal highlights, richly modeled props and dramatic light, calm shadow areas, no grain or excessive microdetail, no logos or interface or borders. Left third mostly atmospheric darker room for webpage copy; characters grouped center-right. Full-bleed artwork.

### Discount Dungeon hero

Use case: stylized-concept. Wide 16:9 premium fantasy game showcase artwork for original humorous collectible universe Discount Dungeon. A mismatched adventuring party in an ancient treasure vault: weary elegant mage inspecting a tiny empty coin purse, green goblin intern hauling a ridiculously large stack of treasure, proud knight with battered armor and sandals, a suspicious treasure chest with small teeth in foreground. Beautiful painterly fantasy concept illustration, expressive believable anatomy, clever visual comedy in a serious dramatic world, warm amber torchlight against plum shadows, ornate weathered stone arches and distant torchlit passages. Strong clear composition and calm shadow surfaces, no excessive grain or microdetail. Left third mostly darker architecture with heroes center-right to allow webpage copy. No words, logos, interface, frames or watermark. Full bleed artwork.

### Orbital Oddjobs hero

Use case: stylized-concept. Wide 16:9 premium retro science fiction game universe showcase for an original humorous collectible card universe Orbital Oddjobs. Three scrappy space salvagers on a battered orbital delivery dock: a copper maintenance robot attempting to repair itself with a spanner, a tired astronaut wheeling a huge parcel on an impractically tiny trolley, and an orange cat proudly occupying a spacecraft pilot chair in the background. A glowing planetary crescent outside immense bay doors. Teal industrial lighting, copper metal, warm cabin light, textured but clean painterly mature game concept art, dramatic depth, readable clear silhouettes, believable machinery with restrained detail. Keep left third dark atmospheric with the action center-right for webpage copy. No text, logos, interface, borders or watermark, full bleed illustration.

### The Last Brain Cell

Create a premium portrait 2:3 collectible card illustration, full bleed with no lettering or card frame. Original character 'Last Brain Cell': a small pink anthropomorphic brain with expressive exhausted eyes, wearing a crooked purple gaming headset, sitting alone on an enormous battered tactical throne made of unplugged game controllers inside a neon gaming command room. It guards a single glowing idea light bulb as if it were the universe's last precious resource. Humor in the contrast between tiny tired brain and monumental heroic staging. Painterly mature video game concept art with crisp focal shape, purple shadows, pink skin, restrained electric teal and warm golden light, tactile materials, beautiful depth, restrained detail, no emoji/flat vector style, no gore, no words/logos. Subject centrally staged upper two thirds; darker atmospheric lower section for card text overlay.

### The Dark Duck

Create a premium portrait 2:3 full bleed fantasy collectible card illustration, no text and no frame. Original character 'Dark Duck': an ordinary small yellow rubber duck wearing an intimidating dark iron crown and enormous dramatic black-purple royal cape, perched on a monumental obsidian throne in a ruined gothic dungeon. The duck's tiny orange beak and harmless dot eyes contrast with the serious ominous royal setting; a tiny wet footprint trail approaches the throne. Warm amber candles, deep violet shadow, exquisite painterly premium fantasy game concept art, high material quality, clean readable focus, controlled detail and no grain. Centered heroic upper two thirds composition, dark atmospheric lower area for card text overlay. No logos, lettering, border, interface, or watermarks.

### Cosmic Rubber Duck

Create a premium portrait 2:3 full bleed science-fiction collectible card illustration, no text and no frame. Original character 'Cosmic Rubber Duck': a glorious golden rubber bath duck inside a round clear astronaut helmet with a copper collar, floating weightlessly before the curved blue horizon of a planet. A luminous thin gold orbital ring forms a halo behind its helmet; a few ordinary soap bubbles float around as though this divine cosmic being took the bath with it. Epic astronaut composition contrasted with wonderfully mundane toy duck, tasteful visual comedy. Mature painterly retro science fiction game concept art, teal space shadow, burnished copper, radiant warm gold, beautiful glass reflections and controlled rich details, strong silhouette, no grain, no emoji style. Subject centered upper two thirds; lower third darker cosmic atmosphere for card text overlay. No logos lettering border or UI.

## Inspection limits

The six standalone images were inspected visually; browser cropping and integration remain the responsibility of the consuming UI. The duck portrait is slightly more characterful than a strictly molded bath toy, and intentionally remains clearly comedic. Fine background props are illustrative, not engineering diagrams.


Delivery assets are optimized WebP derivatives in `dist/assets/v5/`; generated PNG intermediates were removed from the published bundle. Illustrations are generated prototype concepts, not commissions by the fictional studio credits.
