# Edition 11 card-back artwork

Five original universe card backs generated using built-in image_gen, visually inspected on 2026-10-11. No references used. Opaque full-bleed portrait designs with central emblems and no text. Converted to width600 WebP, quality86; no manual visual edits.

## recrues

Path: `dist/assets/v11/recrues-back.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-9dc3c599-f7aa-4f48-a354-def98bae07db.png`

Prompt:

Use case: stylized-concept. Premium collectible trading card BACK illustration, portrait aspect ratio exactly 5:7, full bleed opaque artwork. Perfectly front-on flat card graphic, not a physical tilted card or mockup, no surroundings. Purpose-built symmetrical strong frame and single readable central emblem, beautiful intentional stylized game concept artwork, restrained material detail, clear hierarchy and broad restful surfaces, rich depth in embossing without noisy micro-ornament. No text, letters, numbers or watermark. Violet and acid-lime squad technology: brushed black angular armor frame with violet glass inset, central luminous faceted squad diamond, geometric circuitry restricted to border, premium futuristic tactical aesthetic.

## donjon

Path: `dist/assets/v11/donjon-back.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-fdfb0a78-d692-4be0-ba60-cf12c5610407.png`

Prompt:

Use case: stylized-concept. Premium collectible trading card BACK illustration, portrait aspect ratio exactly 5:7, full bleed opaque artwork. Perfectly front-on flat card graphic, not a physical tilted card or mockup, no surroundings. Purpose-built symmetrical strong frame and single readable central emblem, beautiful intentional stylized game concept artwork, restrained material detail, clear hierarchy and broad restful surfaces, rich depth in embossing without noisy micro-ornament. No text, letters, numbers or watermark. Burgundy leather and warm antique gold fantasy: central friendly duck heraldic seal in a gold medallion, carved curling brass scrollwork frame, restrained rune-like abstract geometry without characters, dark warm leather field.

## orbital

Path: `dist/assets/v11/orbital-back.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-40b03431-b3fc-4a99-8f10-b5d8551f9e0a.png`

Prompt:

Use case: stylized-concept. Premium collectible trading card BACK illustration, portrait aspect ratio exactly 5:7, full bleed opaque artwork. Perfectly front-on flat card graphic, not a physical tilted card or mockup, no surroundings. Purpose-built symmetrical strong frame and single readable central emblem, beautiful intentional stylized game concept artwork, restrained material detail, clear hierarchy and broad restful surfaces, rich depth in embossing without noisy micro-ornament. No text, letters, numbers or watermark. Teal industrial space cargo aesthetic: central ivory ringed-planet orbital seal, teal enamel broad field, dark steel frame with four purposeful inset screws and slim orange warning accents, subtle technical grid.

## couriers

Path: `dist/assets/v11/couriers-back.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-bb9d6665-3a82-4184-b314-8c3c6891018a.png`

Prompt:

Use case: stylized-concept. Premium collectible trading card BACK illustration, portrait aspect ratio exactly 5:7, full bleed opaque artwork. Perfectly front-on flat card graphic, not a physical tilted card or mockup, no surroundings. Purpose-built symmetrical strong frame and single readable central emblem, beautiful intentional stylized game concept artwork, restrained material detail, clear hierarchy and broad restful surfaces, rich depth in embossing without noisy micro-ornament. No text, letters, numbers or watermark. Teal and brass clockwork dispatch aesthetic: central winged envelope seal framed by a circular brass clock mechanism, art deco corner shapes, rich teal leather field, beautifully balanced meaningful gears rather than visual noise.

## moonlit

Path: `dist/assets/v11/moonlit-back.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-abd3a349-3cbf-471d-95b1-aa4e94a43b15.png`

Prompt:

Use case: stylized-concept. Premium collectible trading card BACK illustration, portrait aspect ratio exactly 5:7, full bleed opaque artwork. Perfectly front-on flat card graphic, not a physical tilted card or mockup, no surroundings. Purpose-built symmetrical strong frame and single readable central emblem, beautiful intentional stylized game concept artwork, restrained material detail, clear hierarchy and broad restful surfaces, rich depth in embossing without noisy micro-ornament. No text, letters, numbers or watermark. Indigo velvet and silver moonflower midnight hotel aesthetic: central elegant crescent moon and one star, silver arched ornamental frame, moonflowers curving at lower corners, deep restful indigo velvet field, refined magical elegance.
