# Card Atlas v6 artwork provenance

Generated 2026-10-10 using built-in image_gen.imagegen. These are AI-generated original prototype illustrations, not commissioned or licensed franchise art. Ten generations provide 60 dedicated card scenes, three pack illustrations, and three distinct page environments. All outputs were visually reviewed. Sheets are rendered directly via CSS atlas positions; no image cropping or recomposition was performed. WebP is a format-only encoding at quality90, without resizing. Returned dimensions are approximately1620x972 for card sheets (each portrait cell324x486), despite higher requested generation resolution. Do not claim print-resolution production artwork.

## Mapping

Card sheets use five equal columns and two equal rows, read left-to-right then top-to-bottom. Each cell is2:3. All60 have dedicated scenes; v5 premium portraits may be optionally retained at their existing IDs. The new LastBrainCell cell depicts a tired human with a floating brain rather than an anthropomorphic brain; v5 is a closer match to the earlier canonical design. Some tiny incidental prop marks appear although text was excluded from prompts.

- recrues-01: sheet0.webp, row1, column1: Cardboard Carry
- recrues-02: sheet0.webp, row1, column2: Loot Rat
- recrues-03: sheet0.webp, row1, column3: Open Mic
- recrues-04: sheet0.webp, row1, column4: Tactical Pigeon
- recrues-05: sheet0.webp, row1, column5: Friendship Grenade
- recrues-06: sheet0.webp, row2, column1: RGB Toaster
- recrues-07: sheet0.webp, row2, column2: Respawn Coffee
- recrues-08: sheet0.webp, row2, column3: Competitive Chair
- recrues-09: sheet0.webp, row2, column4: Ghost Ping
- recrues-10: sheet0.webp, row2, column5: Innocent Controller
- recrues-11: sheet1.webp, row1, column1: Sofa Coach
- recrues-12: sheet1.webp, row1, column2: Angry Keyboard
- recrues-13: sheet1.webp, row1, column3: Camo Duck
- recrues-14: sheet1.webp, row1, column4: Volunteer Bug
- recrues-15: sheet1.webp, row1, column5: Foam Shield
- recrues-16: sheet1.webp, row2, column1: AFK Hero
- recrues-17: sheet1.webp, row2, column2: Short-Sighted Sniper
- recrues-18: sheet1.webp, row2, column3: Battle Chicken
- recrues-19: sheet1.webp, row2, column4: King of Excuses
- recrues-20: sheet1.webp, row2, column5: The Last Brain Cell
- donjon-01: sheet2.webp, row1, column1: Intern Goblin
- donjon-02: sheet2.webp, row1, column2: Lukewarm Slime
- donjon-03: sheet2.webp, row1, column3: Flip-Flop Knight
- donjon-04: sheet2.webp, row1, column4: Expired Potion
- donjon-05: sheet2.webp, row1, column5: Suspicious Chest
- donjon-06: sheet2.webp, row2, column1: Accountant Rat
- donjon-07: sheet2.webp, row2, column2: Union Candle
- donjon-08: sheet2.webp, row2, column3: Passive Mushroom
- donjon-09: sheet2.webp, row2, column4: Busy Skeleton
- donjon-10: sheet2.webp, row2, column5: Cardboard Shield
- donjon-11: sheet3.webp, row1, column1: Tech Support Wizard
- donjon-12: sheet3.webp, row1, column2: HR Bat
- donjon-13: sheet3.webp, row1, column3: Dragon on Leave
- donjon-14: sheet3.webp, row1, column4: Axe on Finance
- donjon-15: sheet3.webp, row1, column5: Shy Ghost
- donjon-16: sheet3.webp, row2, column1: Parking Paladin
- donjon-17: sheet3.webp, row2, column2: Paperwork Lich
- donjon-18: sheet3.webp, row2, column3: Gourmet Mimic
- donjon-19: sheet3.webp, row2, column4: The Dark Duck
- donjon-20: sheet3.webp, row2, column5: The Monday Boss
- orbital-01: sheet4.webp, row1, column1: Junior Space Janitor
- orbital-02: sheet4.webp, row1, column2: Express Delivery Pod
- orbital-03: sheet4.webp, row1, column3: Emotional Support Drone
- orbital-04: sheet4.webp, row1, column4: Lunchbox Reactor
- orbital-05: sheet4.webp, row1, column5: Warranty Void Bot
- orbital-06: sheet4.webp, row2, column1: Space Traffic Cone
- orbital-07: sheet4.webp, row2, column2: Moon Roomba
- orbital-08: sheet4.webp, row2, column3: Definitely Not an Egg
- orbital-09: sheet4.webp, row2, column4: Emergency Pizza
- orbital-10: sheet4.webp, row2, column5: Budget Jetpack
- orbital-11: sheet5.webp, row1, column1: Clipboard Commander
- orbital-12: sheet5.webp, row1, column2: Unionised Loader
- orbital-13: sheet5.webp, row1, column3: Asteroid Hamster
- orbital-14: sheet5.webp, row1, column4: Sentient Vending Machine
- orbital-15: sheet5.webp, row1, column5: Lost Probe
- orbital-16: sheet5.webp, row2, column1: Captain Overtime
- orbital-17: sheet5.webp, row2, column2: Cat in the Cockpit
- orbital-18: sheet5.webp, row2, column3: The Spare Parts Titan
- orbital-19: sheet5.webp, row2, column4: Cosmic Rubber Duck
- orbital-20: sheet5.webp, row2, column5: The Final Coffee

Pack atlas has three equal portrait columns: recrues,donjon,orbital. Page backgrounds: binder(private archive),community(collector lounge),printing(artisan atelier).

## Exact prompts

### sheet0

Create a high resolution 3840x2304 illustration atlas with EXACTLY FIVE equal columns and TWO equal rows, exactly TEN independent full-bleed portrait illustrations. Every cell has aspect ratio 2:3. No gaps, no gutters, no dividing border, no text, no numbers, no lettering, no card frames. Each cell is a separate scene and must stay wholly within its own rectangle; no elements cross cells. Consistent premium detailed painterly collectible game card art. Purple neon gaming comedy with tactical streetwear and inventive gaming props, mature graphic novel painterly concept art. Purple/teal lighting. Strong distinct focal subjects, physical depth and lighting, rich scenes, clean readable silhouettes, humorous visual storytelling, no flat vector or emoji art. The ten cells in strict reading order LEFT TO RIGHT across TOP row then LEFT TO RIGHT across BOTTOM row depict:
1. Cardboard Carry: The headset is premium. The armour came with free shipping.
2. Loot Rat: Came for the loot. Left with your cheese and a suspiciously full inventory.
3. Open Mic: Built like a microphone. Somehow still mainly broadcasts chewing.
4. Tactical Pigeon: Excellent reconnaissance. Has already reported your car to every other pigeon.
5. Friendship Grenade: That little spark is the group chat ending.
6. RGB Toaster: Runs hot. Supports bread tracing.
7. Respawn Coffee: Two eyes. One cold stare. Zero concern for your sleep schedule.
8. Competitive Chair: The chair has better support than your entire team.
9. Ghost Ping: Three perfect bars. That cross underneath says otherwise.
10. Innocent Controller: Those colourful buttons have heard some very uncolourful language.
Render the subject of every title literally and make its associated visual joke visible. No written jokes; everything through image. Each illustration independently composed with subject centered upper-middle and supporting environment. This is ten finished artworks arranged as a precise uniform grid, not a contact sheet of cards or a screenshot.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-f0b69019-6ecb-42a5-b383-cb8fff1eec97.png

### sheet1

Create a high resolution 3840x2304 illustration atlas with EXACTLY FIVE equal columns and TWO equal rows, exactly TEN independent full-bleed portrait illustrations. Every cell has aspect ratio 2:3. No gaps, no gutters, no dividing border, no text, no numbers, no lettering, no card frames. Each cell is a separate scene and must stay wholly within its own rectangle; no elements cross cells. Consistent premium detailed painterly collectible game card art. Purple neon gaming comedy with tactical streetwear and inventive gaming props, mature graphic novel painterly concept art. Purple/teal lighting. Strong distinct focal subjects, physical depth and lighting, rich scenes, clean readable silhouettes, humorous visual storytelling, no flat vector or emoji art. The ten cells in strict reading order LEFT TO RIGHT across TOP row then LEFT TO RIGHT across BOTTOM row depict:
1. Sofa Coach: A full headset and a front-row seat to someone else doing the work.
2. Angry Keyboard: The missing key is patience.
3. Camo Duck: A camouflage hat. An enormous orange beak. Flawless concealment.
4. Volunteer Bug: Six legs. Still only needs one to trip up the whole game.
5. Foam Shield: A big shiny cross. Mostly marks where the damage will go.
6. AFK Hero: Headset on. Eyes closed. Contribution complete.
7. Short-Sighted Sniper: A crosshair this large should make missing harder. It does not.
8. Battle Chicken: The comb is natural. The military authority is self-appointed.
9. King of Excuses: All those points. Still none aimed at personal responsibility.
10. The Last Brain Cell: Every wrinkle is another reason not to join the voice chat.
Render the subject of every title literally and make its associated visual joke visible. No written jokes; everything through image. Each illustration independently composed with subject centered upper-middle and supporting environment. This is ten finished artworks arranged as a precise uniform grid, not a contact sheet of cards or a screenshot.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-1def889c-0a68-40c3-8c8f-c26317cd935c.png

### sheet2

Create a high resolution 3840x2304 illustration atlas with EXACTLY FIVE equal columns and TWO equal rows, exactly TEN independent full-bleed portrait illustrations. Every cell has aspect ratio 2:3. No gaps, no gutters, no dividing border, no text, no numbers, no lettering, no card frames. Each cell is a separate scene and must stay wholly within its own rectangle; no elements cross cells. Consistent premium detailed painterly collectible game card art. Fantasy dungeon comedy, amber torches violet shadow, mature painterly fantasy game illustration, weathered stone and rich fabrics. Strong distinct focal subjects, physical depth and lighting, rich scenes, clean readable silhouettes, humorous visual storytelling, no flat vector or emoji art. The ten cells in strict reading order LEFT TO RIGHT across TOP row then LEFT TO RIGHT across BOTTOM row depict:
1. Intern Goblin: The ears hear every instruction. The face suggests none were understood.
2. Lukewarm Slime: Looks like it wants a hug. Feels like a wet sock.
3. Flip-Flop Knight: Steel on top. Annual leave on the bottom.
4. Expired Potion: The bubbles are reassuring. The missing label is less reassuring.
5. Suspicious Chest: Teeth are generally a poor sign in furniture.
6. Accountant Rat: That cheese wedge is a deductible business expense.
7. Union Candle: A tiny flame. A heroic amount of wax on the table.
8. Passive Mushroom: Under that enormous hat is absolutely no intention to help.
9. Busy Skeleton: No brain, no skin, no free slots on the calendar.
10. Cardboard Shield: The wooden cross is load-bearing optimism.
Render the subject of every title literally and make its associated visual joke visible. No written jokes; everything through image. Each illustration independently composed with subject centered upper-middle and supporting environment. This is ten finished artworks arranged as a precise uniform grid, not a contact sheet of cards or a screenshot.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-5b65997a-3f8a-4ea8-8415-9d98eb7629be.png

### sheet3

Create a high resolution 3840x2304 illustration atlas with EXACTLY FIVE equal columns and TWO equal rows, exactly TEN independent full-bleed portrait illustrations. Every cell has aspect ratio 2:3. No gaps, no gutters, no dividing border, no text, no numbers, no lettering, no card frames. Each cell is a separate scene and must stay wholly within its own rectangle; no elements cross cells. Consistent premium detailed painterly collectible game card art. Fantasy dungeon comedy, amber torches violet shadow, mature painterly fantasy game illustration, weathered stone and rich fabrics. Strong distinct focal subjects, physical depth and lighting, rich scenes, clean readable silhouettes, humorous visual storytelling, no flat vector or emoji art. The ten cells in strict reading order LEFT TO RIGHT across TOP row then LEFT TO RIGHT across BOTTOM row depict:
1. Tech Support Wizard: The beard is long because he is still waiting for your system to restart.
2. HR Bat: The wings say vampire. The expression says mandatory training.
3. Dragon on Leave: One little flame. He is doing the absolute contractual minimum.
4. Axe on Finance: The shiny bit is yours. The handle still belongs to the bank.
5. Shy Ghost: Two worried eyes and a sheet. Somehow you are the awkward one.
6. Parking Paladin: That shield protects a sacred, completely free parking space.
7. Paperwork Lich: Two empty eye sockets. Still spots the missing signature.
8. Gourmet Mimic: Polished wood. Sharp teeth. Terrible restaurant seating.
9. The Dark Duck: A terrifying dark crown. Still fundamentally a duck.
10. The Monday Boss: A crown heavy enough to make any morning someone else’s problem.
Render the subject of every title literally and make its associated visual joke visible. No written jokes; everything through image. Each illustration independently composed with subject centered upper-middle and supporting environment. This is ten finished artworks arranged as a precise uniform grid, not a contact sheet of cards or a screenshot.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-decda5c9-6209-41ee-83f2-9d309cadb650.png

### sheet4

Create a high resolution 3840x2304 illustration atlas with EXACTLY FIVE equal columns and TWO equal rows, exactly TEN independent full-bleed portrait illustrations. Every cell has aspect ratio 2:3. No gaps, no gutters, no dividing border, no text, no numbers, no lettering, no card frames. Each cell is a separate scene and must stay wholly within its own rectangle; no elements cross cells. Consistent premium detailed painterly collectible game card art. Retro science fiction salvage comedy, teal/copper/gold palette, mature painterly space game illustration, detailed machinery and atmospheric starlight. Strong distinct focal subjects, physical depth and lighting, rich scenes, clean readable silhouettes, humorous visual storytelling, no flat vector or emoji art. The ten cells in strict reading order LEFT TO RIGHT across TOP row then LEFT TO RIGHT across BOTTOM row depict:
1. Junior Space Janitor: A broom in space. Finally, a job where sweeping things under the rug is physically impossible.
2. Express Delivery Pod: The parcel has rockets. Your missing package has officially escalated.
3. Emotional Support Drone: Those bright little eyes care about you. Until the battery hits three percent.
4. Lunchbox Reactor: The sandwich is cold. The warning light is doing its best.
5. Warranty Void Bot: A screwdriver for an arm. A warranty sticker already in the bin.
6. Space Traffic Cone: Four billion stars. Somehow this orange cone has closed your lane.
7. Moon Roomba: All those wheels, and it still found the one cable on the moon.
8. Definitely Not an Egg: The crack is glowing. The clipboard says this is probably normal.
9. Emergency Pizza: Perfectly round. Mostly edible. Currently achieving escape velocity.
10. Budget Jetpack: Two tanks, one taped hose, and absolutely no return policy.
Render the subject of every title literally and make its associated visual joke visible. No written jokes; everything through image. Each illustration independently composed with subject centered upper-middle and supporting environment. This is ten finished artworks arranged as a precise uniform grid, not a contact sheet of cards or a screenshot.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-f4e2f82d-2110-4998-9f2f-a48eda026f86.png

### sheet5

Create a high resolution 3840x2304 illustration atlas with EXACTLY FIVE equal columns and TWO equal rows, exactly TEN independent full-bleed portrait illustrations. Every cell has aspect ratio 2:3. No gaps, no gutters, no dividing border, no text, no numbers, no lettering, no card frames. Each cell is a separate scene and must stay wholly within its own rectangle; no elements cross cells. Consistent premium detailed painterly collectible game card art. Retro science fiction salvage comedy, teal/copper/gold palette, mature painterly space game illustration, detailed machinery and atmospheric starlight. Strong distinct focal subjects, physical depth and lighting, rich scenes, clean readable silhouettes, humorous visual storytelling, no flat vector or emoji art. The ten cells in strict reading order LEFT TO RIGHT across TOP row then LEFT TO RIGHT across BOTTOM row depict:
1. Clipboard Commander: The helmet is sealed. The clipboard is somehow still more important.
2. Unionised Loader: Huge hydraulic arms. A tiny mug. A legally protected tea break.
3. Asteroid Hamster: That enormous helmet contains one hamster and several bad decisions.
4. Sentient Vending Machine: It has eyes now. Your snack has been judged and withheld.
5. Lost Probe: Two solar panels and a map. Both facing the wrong way.
6. Captain Overtime: The gold visor says captain. The clock says he missed dinner again.
7. Cat in the Cockpit: Both paws on the controls. Neither eye on the destination.
8. The Spare Parts Titan: One colossal arm, two different knees, and a receipt no one can find.
9. Cosmic Rubber Duck: A golden halo and an astronaut helmet. Still squeaks when you press it.
10. The Final Coffee: The cup floats. The spoon floats. The entire station waits for its owner to wake up.
Render the subject of every title literally and make its associated visual joke visible. No written jokes; everything through image. Each illustration independently composed with subject centered upper-middle and supporting environment. This is ten finished artworks arranged as a precise uniform grid, not a contact sheet of cards or a screenshot.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-307525d4-83b8-44b2-a4ce-13865a3bc54d.png

### packs_v6

Create a premium illustrated packaging art atlas in THREE EXACT EQUAL VERTICAL COLUMNS with no gutters. Overall landscape2:1, each individual panel portrait2:3. No lettering, no words, no logos, no photographed wrapper: actual full-bleed artwork designed to print on card pack foil. LEFT: Chaos Crew, neon purple/teal street gaming heroes, heroic headset wearer with improvised cardboard armor and tactical pigeon and electric circuitry, dynamic angular graphic composition. MIDDLE: Discount Dungeon, amber/violet painterly fantasy, ominous magical treasure chest wrapped in enchanted golden chains with a large ornate key floating above, dungeon arches and curling magical smoke. RIGHT: Orbital Oddjobs, teal/copper retro science fiction, battered rocket delivery capsule falling toward an orbital space station, luminous orbital rings and stars. Highly detailed premium game concept art and strong original distinct symbols, polished materials and epic lighting, no text/frame/UI. Each composition independent and centered wholly in its equal panel.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-db021fa1-52ed-47fe-81be-73af16d1d6a7.png

### binder_v6

Create a wide16:9 detailed atmospheric premium game illustration of a private collector's archive, no text/UI. Elegant dark plum wood and leather study with tall cabinets of beautiful binders on both sides, glass display alcoves holding rare glowing fantasy relics, large rich burgundy leather card collecting desk in foreground and gold brass fittings. Cozy amber desk lamps, violet ambient light, rain on distant windows. Mature painterly game environment concept art, sophisticated tactile materials, believable depth, no characters, no lettering. Strong unique luxurious archive identity, middle area relatively calm for webpage content overlay.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-8e8964da-7e10-4f46-be5b-9c48d2b91afc.png

### community_v6

Create a wide16:9 detailed atmospheric premium game illustration of a social gaming lounge, no text/UI. Stylish dark teal and indigo futuristic cafe, curved comfortable booths, warm copper hanging lamps, several young adult collector friends in distant background exchanging trading cards and laughing at a table, a panoramic night city window, plants and shelves of board games with unmarked spines. Mature painterly game environment concept art, cozy social energy, beautiful reflections and tactile materials, not corporate office. Foreground and center calm dim surfaces for webpage content overlay, no readable lettering, no logos.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-574af342-7efe-4920-b28f-67adde5b1519.png

### printing_v6

Create a wide16:9 detailed atmospheric premium game illustration of a boutique physical card printing and packing atelier, no text/UI. Beautiful warm cream paper stock, olive metal vintage-modern precision printing press, brass rollers, color ink jars, neatly stacked card sheets, craft tools, open cardboard mailers, cotton gloves on wooden workbench. Sunlit amber workshop with teal shadow, elegant tactile paper and leather materials, mature painterly game environment art. No characters, no lettering/logos. This is a warm artisan studio distinctly different from a dark gamer room, central region softly calm for webpage overlay.

Source: /workspace/scratch/9f8298f0e77d/generated_images/exec-65bf1763-af55-487e-8478-cc9b965d5ab5.png

