# Edition 7 artwork

Generated with the built-in image generation tool, 10 October 2026. These are original prototype illustrations, not licensed franchise artwork or commissioned final production art. All nine outputs were visually inspected. PNG outputs were encoded as WebP using Sharp, quality 90 (91 for card sheets); no compositing or destructive cropping.

## Assets and layout

- `dist/assets/v7/couriers-1.webp`, `couriers-2.webp`, `moonlit-1.webp`, `moonlit-2.webp`: 1619 × 971; each is a five-column, two-row atlas of portrait art. CSS background size 500% 200%; cell positions x=0/25/50/75/100%, y=0/100%. Each sheet maps ten consecutive cards. All subjects and visual jokes inspected in source images.
- `packs.webp`: 1448 × 1086; two equal portrait panels: couriers then moonlit. Background size 200% 100%.
- `discovery.webp`: 1672 × 941; purpose-composed collector observatory, portal to right, atmospheric left-side space for UI.
- `couriers-hero.webp`: 1672 × 941; purpose-composed copper postal hall, robots and parcels right, quiet teal architecture left.
- `moonlit-hero.webp`: 1672 × 941; purpose-composed nocturnal animal hotel, fox reception right, quiet indigo architecture left.
- `binders.webp`: 2172 × 724; five equal art-insert panels in order recrues, donjon, orbital, couriers, moonlit. Background size 500% 100%. Inserts should preserve original colours; user-selected colours should affect surrounding binder parts.

## Prompt set

Card sheets requested exactly five columns × two rows without gaps or text, each cell portrait 2:3, polished clean detailed painterly game illustration and readable visual jokes. Couriers palette copper/teal/amber, whimsical steampunk delivery city. Menagerie palette indigo/rose/silver with warm hotel candlelight. Each card scene appears in the mapping below. Card order is row-major.

Packs prompt: two portrait flat printed artworks side-by-side, no labels or borders; left copper robot riding winged clock delivering an envelope over clockwork city, right regal black cat in crescent crown with owl and fox at enchanted midnight hotel.

Discovery prompt: widescreen purpose-composed collector observatory at twilight, navy/purple left-side negative space for text, right-side glowing circular display portal, floating crystal relic cards and universe windows, architectural storytelling, no people or text.

Couriers hero prompt: widescreen grand copper clockwork postal sorting hall, teal glass windows, mail tubes and little delivery robots carrying oversized parcels toward the right; left 45% calm teal architecture and empty desk for headline.

Menagerie hero prompt: widescreen indigo velvet rose-gold hotel lobby, crescent window and moon, fox concierge right, owl on lamp, cat asleep on chair, garden beyond; left 45% quiet indigo architectural space.

Binder inserts prompt: five equal vertical panels in one 3:1 atlas, no cover edges/spines/text; Chaos masked gaming squad and foam shield (purple/lime), Dungeon goblin and crowned dark duck beside treasure (amber/emerald), Orbital astronaut and cat in cockpit (teal/navy), Couriers ornate robot with envelope and clockwork city (copper/teal), Menagerie regal black cat among flowers and hotel (indigo/rose/silver).

## Card mapping and visual joke copy

- **couriers-01 Oversized Delivery** — The parcel has hired a robot to carry itself.
- **couriers-02 Return to Sender** — The letter goes in. The same pigeon comes out.
- **couriers-03 Magnetic Personality** — His compass has followed the magnet for three districts.
- **couriers-04 Boiling Point** — He needs a quiet moment. And a mug.
- **couriers-05 Fragile Confidence** — Handled with confidence. Unfortunately, it needed care.
- **couriers-06 Express Snail** — Even the organic competition is pulling ahead.
- **couriers-07 Parcel First** — The box stays dry. Employee maintenance is another department.
- **couriers-08 Tailspin Terrier** — That suspicious key has followed him all morning.
- **couriers-09 Out of Office** — Every envelope is marked urgent. The pillow wins.
- **couriers-10 Small Maintenance** — Polishing the tool is his entire apprenticeship.
- **couriers-11 Square Wheel Special** — Every revolution is a workplace incident.
- **couriers-12 Dragon Mail** — Your parcel arrived toasted on both sides.
- **couriers-13 Nested Luggage** — One more suitcase and he qualifies for overtime.
- **couriers-14 Screw Feeder** — Please do not feed the birds imperial fittings.
- **couriers-15 Eight-Handed Sorting** — Eight arms. Not one correct address.
- **couriers-16 Rocket Butler** — Tea will be served shortly. Somewhere.
- **couriers-17 Walking Inbox** — He has forty unread letters and several on his face.
- **couriers-18 Daylight Savings** — He saved some daylight. Nobody mentioned a container.
- **couriers-19 The Last Postwyrm** — An entire dragon protects your invitation to a dentist.
- **couriers-20 Midnight Dispatch** — The clocktower flies because the coffee cannot be late.
- **moonlit-01 Overnight Baggage** — One guest. Twelve suitcases. No visible limbs.
- **moonlit-02 Upside-Down Owl** — Your booking exists. He is simply reading it from Australia.
- **moonlit-03 Marshmallow Hedgehog** — The hotel buffet has developed legs.
- **moonlit-04 Suitcase Concierge** — Your luggage now belongs to management.
- **moonlit-05 Moon Tea** — Decaffeinated. Still causes tides.
- **moonlit-06 Teacup Spa** — Five stars. Slightly herbal.
- **moonlit-07 Sheet Bat** — The ghost is included in the cleaning fee.
- **moonlit-08 Lamp Romance** — He requested a room with a view of the lamp.
- **moonlit-09 Rabbit Recursion** — The assistant has hired an assistant.
- **moonlit-10 Crescent Disaster** — Tonight the croissants match the dark side of the moon.
- **moonlit-11 Glitter Snail** — His entrance lasts longer than the event.
- **moonlit-12 Cheese Knight** — He will secure the perimeter. Then eat it.
- **moonlit-13 Grand Entrance** — The entrance is grand. Entering is another matter.
- **moonlit-14 Piano Otter** — Tonight: an uninterrupted performance in D-sleep.
- **moonlit-15 Dramatic Possum** — The room service charge was too much to bear.
- **moonlit-16 Backward Stargazer** — After years of research, the moon appears to be a paw.
- **moonlit-17 Antler Florist** — He cannot clock out until the flowers stop blooming.
- **moonlit-18 Formal Jellyfish** — Black tie mandatory. Skeleton optional.
- **moonlit-19 Moon Dragon** — No vacancies. The dragon is using the entire hotel as a pillow.
- **moonlit-20 The Night Manager** — Your complaint has been placed in the universe-containing teacup.
