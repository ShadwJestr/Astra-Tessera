# Astra Tessera: first prototype plan

Working title and visuals are temporary. This plan reconstructs the Nyx discussion retrieved on 9 October 2026; it does not claim a complete transcript.

## Confirmed vision
A digital-first collecting platform spanning multiple licensed franchises. Customers pull cards in affordable randomized digital packs and own the exact quantities pulled. Physical cards are optional: customers pay manufacturing and delivery, rather than a rarity markup. Only owned quantities may be printed. Batch orders, optional premium binders, artist recognition and fewer unwanted physical duplicates matter. Commercial art would come from paid artists, with distinct styles and officially allowed collaborations. The initial prototype is free; actual physical fulfillment is later scope. Content, economy, rules and UI must be easy to change. The user supervises visual direction. Additional product proposals are not approved business decisions.

## Product and experience
The first loop is browse a collection, inspect pack odds, open a pack, see each pull, review a saved binder and work toward missing cards. Ownership quantities must be visible; rarity must never imply an extra physical purchase fee. Browsing should connect collection and artist metadata. A future print flow needs a clear distinction between digital copies, printable entitlements, queued items and fulfilled items.

Prototype routes: discover collections; pack opening with individual reveal; binder with collection, rarity, artist, ownership and name filters; card details; artists; simulated print basket/history; workshop for configurable economy and content; a planning/readme screen. Persistent browser-local state with export/import. No real accounts, transactions, fulfillment or copyrighted franchise content.

## Collecting proposals for evaluation
All numerical defaults below are prototype choices, not user-approved rules.
- Five cards per pack; 100 demo credits; 1,000 starting credits and a free refill button.
- Common 70%, uncommon 23%, rare 6%, legendary 1% per ordinary slot.
- Every tenth pack without a rare-or-better guarantees rare-or-better in its final slot. A qualifying pull resets the counter. The guarantee's rare/legendary split follows their relative base weights.
- Optional duplicate protection redirects the first slot to an unowned card of its rolled rarity in that collection, if one exists. It does not alter rarity odds.
- Recycling converts only surplus, unprinted copies into fragments; at least one digital copy remains. Optional crafting lets fragments obtain a specific missing card. This is a completion mechanism to evaluate, not a finalized commercial economy.
- Physical simulation consumes one printable entitlement per owned copy, while preserving digital ownership. This is a conservative provisional interpretation: it prevents printing the same entitlement repeatedly. Real redemption semantics remain an open decision.
- No trading, cash-out, marketplace, blockchain, scarcity claims or purchases in this prototype. These are not implicit requirements.

## Economy and business viability
The user's target is packs roughly five times cheaper than physical packs, far below physical €5–8 prices. The demo uses credits, not a claimed feasible euro price. Scale and batching are hypotheses, not proof of margins. Before commercial launch, model licensing royalties/minimum guarantees, art fees, payments, VAT, hosting, support, refunds, fraud, moderation, printing/finishing, packaging, damaged delivery, shipping, warehousing and customer acquisition. Compare revenue against these costs at low/medium/high volume; do not assume a large audience will materialize. Rarity must not change the per-card print price for the same format/finish. Premium finishes or binders could carry actual product cost differences, to be approved separately.

## Architecture and modularity
Buildless ES modules. catalog.js contains independently identified artists, collections, cards and pack definitions; core.js handles pure transactional rules and validation; app.js renders and connects interactions; styles.css controls presentation. Tests call the core without a browser. Stable IDs protect saves when titles/art change. Removed cards remain archived when copies are owned or previously printed. A configurable workshop can add content, edit economy, disable collection sales and export the catalog. Deleting unowned content is separate from archiving owned content. No paid library/runtime is required.

Production evolution: authoritative server-owned inventory ledger; authentication; transaction idempotency; cryptographically secure server draws; versioned rule snapshots; durable database, migrations, backup/recovery; order reservation and fulfillment state machine; payment integration and abuse defenses; operational audit trail. Browser-local state is intentionally editable and is unsuitable for money or rare assets. A production account/backend and cross-device saves are outside this first slice.

## Licensing, legal and operations planning
Commercial use of third-party franchises requires licenses with approved territories, mediums, artwork and redemption rights. Artist agreements should specify compensation, attribution and digital/physical usage. Do not represent placeholder art as a real commission or collaboration. Before monetization, obtain jurisdiction-specific advice on randomized purchases, minors, consumer disclosures, refunds, digital rights and privacy; verify applicable law rather than treating this outline as advice. Publish honest odds and protection rules. No monetization is enabled now.

Operations need a supported printer and proofs, color/finish standards, minimum order quantities, shipping quotes, batch cutoffs, tracking, returns/defects policy, customer support, rights takedown handling and accessibility. The simulated print flow does not place orders or collect delivery details.

## Open decisions
Exact prices/pack sizes/rarities, duplicate and completion mechanisms, changing odds over time, card transferability, redemption semantics, publisher/artist terms, permitted visual style, commercial regions/age policy, supported print formats/binders and backend stack. Temporary choices can be replaced without making them approved policy.

## Completion checks for this slice
A user can open packs, inspect exact quantities, reload and retain the binder, filter content, recover a save through export/import, use optional completion mechanics, and simulate a print order without exceeding entitlements. Invalid imports must leave the existing save untouched. State-changing operations must be transactional; invalid inputs cannot charge credits or delete cards. Configuration/content changes must validate before use. Automated tests verify these behaviors. A private hosted build is the reviewable result; browser visual QA may be unavailable in this runtime.

## Edition 02: requested design iteration (10 October 2026)
The user requested effects on card opening, two fake 20-card collections, light absurd humour and a UI restyled using their preferences. Edition two initially used French text; edition three uses English following the user’s correction. Added Les Recrues du Chaos and Donjon Discount: original names, roles, flavour text and code-made vector portraits. These are collectible demo sets, without combat stats or gameplay rules. The interface uses readable bolder text, dark plum surfaces, purple accents, rounded controls and explicit dropdown arrows. Opening effects have skip/motion controls; system reduced-motion is respected, and synthesized sound is opt-in. No external creator’s character, identity or text is copied.

First-edition inventory is preserved through a versioned content migration. Old collections/cards are archived rather than deleted; custom content and economy settings remain. Tests cover migration and opening skip/double-click behavior. Browser layout/animation timing requires real browser verification when that capability is available.

## Previous collection experience (edition 03)
Chaos Crew and Discount Dungeon contain 20 original cards each, with English names and jokes referring to visible illustration details. Examples include RGB Toaster (bread tracing), Cardboard Carry (taped cardboard armour under a gaming headset), Flip-Flop Knight (helmet plus visible sandals), and Parking Paladin (a P-marked shield). Translation upgrades retain stable IDs and preserve deliberate custom text edits.

The binder home contains chosen franchise folders. Owned cards appear by default inside a folder, with an explicit missing-card toggle. Opening a pack or crafting a card adds its franchise folder; removing a folder hides it without deleting cards, print entitlements or history. Older saves infer folders from ownership until the user makes a folder selection.

Pack openings are interactive: click the pack or its button, then break the seal. Chaos has a purple neon theme; Dungeon has warm ember/gold effects. The results are saved before animation. Presentation sorting puts lower rarities first and rare/legendary pulls at the end, preserving the exact draw result and unchanged odds. The initial offset stack has a face-down top card and visible rarity-coloured edges. The first reveal click flips it; later clicks animate it into a tidy vertical right-hand column and reveal the next card. Multiple legendaries occupy the final slots. The final click files the last card. Skipping animations/results and system reduced-motion remain supported. This is presentation, not a new guarantee that every pack contains a rare.

## Current collection experience (edition 04)
Three original demo universes contain 60 cards in total. Orbital Oddjobs adds 20 sci-fi crew, robots, delivery hardware and oddities, with English visual jokes. Existing saves receive the new content without replacing customised titles, archived cards, paused collections, balances, quantities or economy rules.

Card frames differ by universe and rarity. Environmental SVG artwork and extra costume/prop details accompany faint artwork behind text. Discovery is an illustrated storefront, the binder a warm textured album, openings a dark collecting table, artists a gallery and printing a proof studio. These are original demo universes, not third-party franchise implementations.

Openings have brief manual interactions: slide/tear a foil seal, strike three chest seals, or enter a five-arrow delivery code. Autoplay (button, S or Escape) performs the input sequence and runs the same animation. The first two openings in each universe play at full pace; the third offers normal or 1.6× speed. The choice is saved locally and can be changed in Workshop. Motion reduction still bypasses animation.

Filed cards remain in stable right-column slots. Advancing animates the top card and inserts one new arrival without rebuilding the rail or replaying previous arrivals. The advance label is Next. Lower rarities precede higher rarities, with equal-rarity draw order retained. Presentation does not change the pack distribution or guarantees.

Checks cover accounting, all migrations, opening commands/preferences, sequential reveals, retained rail nodes and app workflows using DOM stubs. Art samples were inspected from an SVG rendering. Real browser layout, touch interaction and animation timing still need browser verification when that capability is available.


## Edition 05 implementation update
Astra Tessera is the chosen name. The prototype now includes illustrated discovery, franchise catalogs and binder shelves, custom covers and spacing, local collector profiles/showcases, fictional social activity, protected bulk recycling, saved pack boxes, gesture-based reveals, and simulated shared parcels for prints and merchandise. Generated premium concept portraits supplement the existing vector demo catalog. Artist studio names and community identities are fictional; commercial artist credits and IP partnerships remain future integrations.

All balances and ownership still live in the browser. Export/import carries the catalog, inventory, print reservations, preferences, cosmetic unlocks, local social data, paid pack queue and reveal position. This is not a production ownership ledger or a real store.


## Edition06 review batch
The collecting interface now includes full-catalog paintings, dedicated pack illustrations, distinct collector-room art, free six-part binder colours, collectible binder structures, direct pack/card manipulation, automatic batch sequencing, correct franchise purchase ordering, context-preserving artist navigation and modal showcase selection. Local profiles can display favourite-game tags and a manually added Steam profile link. Studio news is editorial prototype content; no live news service or account linking is connected.


## Edition 07 checkpoint

Five original universes, 100 cards. Clockwork Couriers and Moonlit Menagerie join the existing three with new visual concepts, rituals and covers. The current feedback ledger is docs/EDITION_07_BRIEF.md. Functional completion and visual approval are distinct: purpose-made concepts and refined geometry are implemented, while final art direction and browser-measured motion remain unapproved. The live application remains a local prototype, not a payment or social backend.

## Edition 08 checkpoint
Actual-page appearance previews, a showcase-first lounge, visual game favourites, local guestbook, drag ordering, dimensional pack/box planes, sticky navigation and five purpose-composed opening worlds. Discovery leads with the two new universes. Clockwork and Moonlit rituals are now distinct mechanisms. See EDITION_08_BRIEF.md for coverage and explicit production/verification limits.
