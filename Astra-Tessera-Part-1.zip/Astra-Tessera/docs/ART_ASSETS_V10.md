# Edition 10 original artwork

Generated with the built-in image_gen tool on 2026-10-10. All fourteen assets visually inspected before integration. Binder assets have real alpha transparency; conversion preserves generated transparency. Original generations remain in scratch. No manual image retouching. Binder images optimized to 800px width, quality88 WebP with alpha; foreground prop layers optimized to at most1200×675. Dungeon alpha verified by compositing onto a dark plum surface; apparent colored fringe in raw viewer is absent in normal alpha composition.

## recrues

Path: `dist/assets/v10/recrues-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-46d87996-6537-4447-ae41-c3d2c3098373.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Chaos Crew: angular futuristic hard-shell holo binder, violet black armor panels, acid-lime narrow edge accents, translucent holographic inset with abstract geometric circuit emblem, asymmetric clipped corners, thick dark spine, sturdy sleek latch. Playful premium esports equipment.

## donjon

Path: `dist/assets/v10/donjon-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-e9d00747-75ea-4948-900c-8c1bbe656ba8.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Discount Dungeon: carved dark burgundy leather spellbook binder with brass fittings, sculpted friendly duck-head crest in center, aged cream paper edges, thick rounded raised spine ribs, broad elegant scroll-shaped brass corner guards and leather clasp. Warm collectible fantasy prop, witty but beautiful, no extra objects.

## orbital

Path: `dist/assets/v10/orbital-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-51042a44-fa2a-4087-9776-a9cda252ee87.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Orbital Oddjobs: blue-teal industrial spacecraft cargo field binder, rounded rugged steel shell, inset pale-teal enamel panel with a simple orbital diagram emblem, visible precision hinges, orange small safety latch, thick graphite rubber spine and protective corners. Practical retro space explorer equipment.

## couriers

Path: `dist/assets/v10/couriers-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-f3887a34-5dcf-4ab2-ad4a-17377b9aa65c.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Clockwork Couriers: tall teal leather mechanical dispatch ledger with brass spine, large clean articulated clockwork circular clasp on front, cream porcelain inset medallion, wing-shaped brass corner geometry, visible book thickness and elegant hinge. Strong art deco and steampunk industrial product design, a few purposeful gears not visual clutter.

## moonlit

Path: `dist/assets/v10/moonlit-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-d106ac19-9c34-47f8-9013-0548fff7739e.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Moonlit Menagerie: indigo velvet arched-top collectible book cabinet binder, silver crescent moon crest, restrained painted moonflower vines, scalloped silver cover rim, elegantly curved thick spine, small pearl clasp. Distinct cathedral-window silhouette and whimsical boutique midnight hotel object. Refined silver/indigo/soft lavender.

## gallery

Path: `dist/assets/v10/gallery.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-b010e35b-1620-4afd-aef7-c33a7bb10f31.png`

Prompt:

Use case: stylized-concept. Original widescreen 16:9 environment artwork for a premium collectible card website's personal gallery. An intimate beautifully designed nocturnal collector's atelier, eye-level slightly elevated wide view, calm dark plum walls and walnut display shelving, restrained brass trim, warm indirect shelf lighting, subtle violet window glow. Central broad EMPTY dark work surface occupies lower 45 percent, empty shallow display niches at sides and rear upper third; space ready for separately composited binder/card UI. Architectural depth and physically believable surfaces, tailored game environment concept painting with crisp designed large shapes and restful detail hierarchy, not photoreal grain. Asymmetric tasteful lamp and one sculpted abstract brass ornament tucked at far edges, no books, no cards, no posters, no text, no logos, no people, no clutter. Central 60 percent calm low contrast usable negative space, beautiful expansive material craftsmanship, no extreme highlights.

## Review notes

All binders have readable three-quarter depth, a visible spine and a closure. Chaos is angular hard-shell; Dungeon has warm leather and duck crest; Orbital uses rugged cargo hardware; Couriers uses dispatch clockwork; Moonlit has an arched floral silhouette. Gallery deliberately leaves its large central surface clear for real UI. These are product concepts, not photographs of manufactured goods. Raster artwork should not be globally hue-rotated for customization; recolour separately rendered trim/panels instead.
## donjon-desk-props

Path: `dist/assets/v10/donjon-desk-props.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-d9496a08-cceb-4e64-aaca-978a1969d51f.png`

Prompt:

Use case: stylized-concept. Transparent foreground prop arrangement for a collectible card game's fantasy dungeon opening desk. Wide 16:9 transparent canvas. ALL objects contained in leftmost 22 percent of canvas and bottom-left corner. CENTRAL 70 percent and entire rightmost 25 percent MUST BE EMPTY ALPHA TRANSPARENCY, no connecting horizontal lines, no background, no backdrop. A short burning candle in a chunky brass holder, one elegant purple potion bottle, rolled cream parchment and duck-shaped red wax seal, clustered as physical tabletop props at the far left. Slight overhead three-quarter view looking down onto props. Warm brass burgundy wood accents, clean polished game concept product rendering, crisp intentional shapes, restrained detail, believable material depth, soft contact shadows restricted to immediately underneath props. No text, letters, cards, books or people. Keep all props entirely in view with margin. True transparent background.


## recrues-desk-props

Path: `dist/assets/v10/recrues-desk-props.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-38997a3e-fa92-4248-891e-f2e2c7f99989.png`

Prompt:

Use case: stylized-concept. Transparent foreground prop arrangement for a collectible card game's opening desk. Wide 16:9 transparent canvas. ALL objects contained in leftmost 22 percent of canvas and bottom-left corner. CENTRAL 70 percent and entire rightmost 25 percent MUST BE EMPTY ALPHA TRANSPARENCY, no connecting horizontal lines, no background, no backdrop. Slight overhead three-quarter view looking down onto props. Clean polished game concept product rendering, crisp intentional shapes, restrained detail, believable material depth, soft contact shadows restricted to immediately underneath props. No text, letters, cards, books or people. Keep all props entirely in view with margin. True transparent background. Chaos Crew futuristic gaming squad desk: compact violet hologram projector displaying a small abstract lime diamond, a black/violet game controller, tiny angular mascot charm and curled lime cable.


## orbital-desk-props

Path: `dist/assets/v10/orbital-desk-props.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-e7d38257-0eb6-4aca-8e53-e19fca734ff9.png`

Prompt:

Use case: stylized-concept. Transparent foreground prop arrangement for a collectible card game's opening desk. Wide 16:9 transparent canvas. ALL objects contained in leftmost 22 percent of canvas and bottom-left corner. CENTRAL 70 percent and entire rightmost 25 percent MUST BE EMPTY ALPHA TRANSPARENCY, no connecting horizontal lines, no background, no backdrop. Slight overhead three-quarter view looking down onto props. Clean polished game concept product rendering, crisp intentional shapes, restrained detail, believable material depth, soft contact shadows restricted to immediately underneath props. No text, letters, cards, books or people. Keep all props entirely in view with margin. True transparent background. Orbital Oddjobs spacecraft workbench: compact rugged teal radar instrument with circular green screen, small graphite oxygen canister with orange valve, two blank metal mission tags on a short loop.


## couriers-desk-props

Path: `dist/assets/v10/couriers-desk-props.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-15135cfa-42d1-47a9-8a0f-21d89b5f0d68.png`

Prompt:

Use case: stylized-concept. Transparent foreground prop arrangement for a collectible card game's opening desk. Wide 16:9 transparent canvas. ALL objects contained in leftmost 22 percent of canvas and bottom-left corner. CENTRAL 70 percent and entire rightmost 25 percent MUST BE EMPTY ALPHA TRANSPARENCY, no connecting horizontal lines, no background, no backdrop. Slight overhead three-quarter view looking down onto props. Clean polished game concept product rendering, crisp intentional shapes, restrained detail, believable material depth, soft contact shadows restricted to immediately underneath props. No text, letters, cards, books or people. Keep all props entirely in view with margin. True transparent background. Clockwork Couriers steampunk dispatch station: small brass pressure gauge on a dark teal block, polished brass service bell, short copper tubing and a little wing-shaped mechanical token.


## moonlit-desk-props

Path: `dist/assets/v10/moonlit-desk-props.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-57dae584-bdc8-4e28-8818-85999e0bcb4c.png`

Prompt:

Use case: stylized-concept. Transparent foreground prop arrangement for a collectible card game's opening desk. Wide 16:9 transparent canvas. ALL objects contained in leftmost 22 percent of canvas and bottom-left corner. CENTRAL 70 percent and entire rightmost 25 percent MUST BE EMPTY ALPHA TRANSPARENCY, no connecting horizontal lines, no background, no backdrop. Slight overhead three-quarter view looking down onto props. Clean polished game concept product rendering, crisp intentional shapes, restrained detail, believable material depth, soft contact shadows restricted to immediately underneath props. No text, letters, cards, books or people. Keep all props entirely in view with margin. True transparent background. Moonlit Menagerie midnight hotel desk: delicate silver crescent desk lamp on indigo base, small deep-violet vase with three pale moonflowers, and an elegant silver star-shaped key. Soft lavender glow.


## classic-binder

Path: `dist/assets/v10/classic-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-68babfcc-b08a-4e21-8735-101f105d5de4.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Classic archive binder: simple warm tan leather with elegant brass corner protectors and one modest leather strap clasp, unadorned front panel, cream edges, rounded thick spine. Understated and warm, less elaborate than fantasy trophy books.


## velvet-binder

Path: `dist/assets/v10/velvet-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-8cb7e9c7-0b22-4db5-b360-7ccdc7a840a9.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Midnight velvet binder: rectangular midnight violet fabric cover, slender silver edge trim and a small circular silver celestial medallion centered on front, plain smooth spine and neat silver clasp. Understated modern luxury, clean simple rectangular silhouette, no arch or flowers.


## slate-binder

Path: `dist/assets/v10/slate-binder.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-7af2471e-a2a5-4912-bcb9-d59f5b353731.png`

Prompt:

Use case: product-mockup. A standalone physical collectible card binder product asset for a premium game-world collecting website. One closed binder standing upright, three-quarter view with front cover and left spine visible, entire object centered with generous transparent margin. Genuine transparent background, no floor or backdrop, no text or letters or watermark. Crisp intentional stylized game concept art with clean readable big shapes, restrained details, believable thickness, manufactured hinges and clasp, beautiful soft studio lighting, sharp silhouette. Not a flat rectangle, not excessive tiny ornament or noisy AI detail. Carbon slate binder: graphite carbon modern geometric hard-case, subtle charcoal angular panel seams, a small brushed steel rectangular clasp, sturdy dark spine. Understated minimalist collector equipment, no neon glow or logos.


Foreground review: generated prop clusters occupy the left35–40% of each transparent canvas (not the requested22%). Integrate as a bounded scaled left-edge layer, keeping active card/tray space clear. All eight binder variants are visually inspected; basic three use quieter shapes/materials than earned world designs.
