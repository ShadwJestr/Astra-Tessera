# Edition 05 — user annotations and delivery scope

The user explicitly authorized implementation of all 25 annotations plus coherent improvements on 2026-10-10, after asking us to wait while collecting batches. All written comments arrived; annotation image files were unavailable. Preserve this list as the review checklist.

1. Social features.
2. Richer Print Studio.
3. Discovery carousel with arrivals, recommended packs, social highlights, franchise merch and combined shipping concept.
4. Social content lower on discovery.
5. Missing-card stats scoped to selected/favourite franchises, with per-franchise drilldown.
6. Illustrated page backgrounds.
7. Free layout customization plus earned cosmetics; a rare bonus sixth card can unlock a franchise binder.
8. More manageable, visually interesting binders.
9. Allow recycling the last owned copy behind two warnings; protect valuable cards from accidental recycling.
10. Fix missing card text in detail view.
11. Clickable artist credit in card/details leading to all the artist's work.
12. Bulk recycling with filters.
13. Main catalog navigation is franchise-based; artists remain discoverable through credits.
14. Multiple packs in sequence, boxes with their own themed opening and a pack count.
15. More impressive franchise opening effects.
16. One coherent illustrated card-back design per franchise.
17. Open another pack from the reveal screen.
18. Rarity-scaled card reveals; legendary theatrical animation.
19. Stronger franchise frames and premium artwork.
20. Illustrated opening table and physical drag to reveal/file; invalid drops spring back.
21. Global Back.
22. Match interactions to object/franchise; dungeon chest uses key, not arbitrary breaking.
23. Clear insufficient-credit feedback at purchase.
24. Direct foil tearing on pack; inspect/rotate packs and cards with light-reactive foil.
25. Next plays transition faster.

## Product choices for this pass
- Retain original 60-card catalog and stable IDs, existing ownership, economy, orders and custom content.
- Fictional social demo with local follows/likes/profile/showcase; no messages sent to other people.
- Merchandise and combined print quote/order are simulated and labelled. No payment or shipping data.
- Persist paid pack queue and reveal position; refresh cannot lose a purchased box.
- Cosmetic bonus is additional to normal cards, explicitly stated chance, no paid advantage. Free customization always available.
- Protect print entitlements, queued print copies and manually locked cards when recycling. Preview exactly what will be removed. Last-copy removal requires a second confirmation.
- Add favourites, wishlisting, folder sort/order/skin, profile showcase, search, responsive controls, reduced motion and keyboard alternatives.
- Work remains browser-local and private. Browser QA unavailable unless the supported control-browser skill becomes available.

## Delivery status
Implemented all 25 items as browser-local prototype interactions. Site renamed Astra Tessera. Social and fulfillment remain explicitly simulated. Six generated paintings supplement 60 stable card entries. Domain and DOM-stub tests cover the principal flows; real-browser visual verification is unavailable in this environment.
