# Edition 11 — Craft and feel

## Agreed direction
- A 2D interface with depth and in-world materials, not a navigable 3D videogame.
- Shared interaction structure; distinct world atmosphere and object details.
- Neighbours lean progressively away from dragged objects and return when the object retreats. Do not jump immediately into a new slot.
- Strong binder art takes priority over recolouring. Selective recolouring requires layered/masked artwork and is deferred rather than degrading the designs.
- Modest vertical scrolling is preferable to cramped controls. Phone-specific redesign and economy balancing remain separate phases.
- Fake currency, fictional cards and simulated merchandise remain the prototype's scope. Real commerce is not required.

## This release
- Smaller opening cards with restored movement room, continuous eased boundary resistance and restrained tilt.
- Earlier release guide based on the card's leading edge. Filing remains release-only; dragging hidden cards does not reveal them.
- Gentle distance-based neighbour displacement and tilt; order only saves on release.
- Width-filling opening environment, more comfortable header, vertically stacked actions.
- Five distinct structural frame treatments: squad hardware, fantasy brass/leather, industrial cargo fittings, clockwork brass and lunar silver. Ornate/prestige levels receive greater ornament and material emphasis.
- Five purpose-built card-back illustrations, also used for earned completion emblems.
- Side page-turn controls across album-based collections.
- Smaller binder design tiles, ownership/world filters, bounded scrolling inside the design list, independent preview, optional trim controls. Preview cannot be dragged or reorder the real collection.
- World-specific completion honours on the profile; distinct small completion emblems in the lounge.
- What's new and the in-site design review updated to distinguish settled decisions from open questions.

## Latest annotations
1. Smaller card, fluid movement: implemented; tactile quality still requires human browser review.
2. Earlier insertion marker: implemented and shares release geometry.
3. Existing table composition: retained.
4. In-world edge detail: five distinct crafted frame systems.
5. Fill table width: outer opening margins removed.
6. Three stacked end actions: restored.
7. Rarity/tier detail: expanded frame fittings and prestige crowns.
8. Less cramped header: relaxed viewport-only constraint.
9. Side pagination: implemented.
10–12. Compact binder chooser, fixed selection area and filters: implemented.
13. Non-draggable preview: pointer gesture removed and native image dragging blocked.
Additional three: side controls also in binders; illustrated part recolouring deferred by agreement; profile completion honours added.

## Still provisional
- Two art-direction folders have not been supplied yet. New backs fit the current five worlds; this is not a claim that all existing card art has reached final quality.
- New frame composition, card movement speed and neighbour hesitation need real visual/interaction review.
- Colour controls explicitly change display trim only. They do not recolour the illustrated binder.
- Phone UI still needs its own design pass.
- No new actual payments, external social service, cloud inventory or shipment functionality.

## Validation
69 tests pass, including geometry for progressive yielding, early filing-zone detection, and bounded continuous movement. DOM-stub smoke tests cover actual application flows but cannot verify browser rendering or animation feel. Supported browser-control tooling is unavailable in the managed environment, so full browser QA remains outstanding.
