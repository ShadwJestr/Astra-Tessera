# Astra Tessera — round 6, 40 written annotations
1 Live customization preview beside controls.
2 Auto discovery carousel with unboxed edge arrows.
3 News/editorial and other carousel content.
4 Actual card illustrations for all cards; substantive franchise borders.
5 Larger universe introduction and pack CTA; cards lower down.
6 Dedicated pack artwork; physical manipulation on store.
7 Remove universe selector within its pack store.
8 Visual pack quantity options.
9 Multiple singles visually grouped; actual box with visible packs/lid.
10 Automatically advance successive packs.
11 Improve seal-tear animation.
12 Directional bend/foil on special card drag; dragging hidden card must NOT reveal.
13 Next beneath stack; top corner open-all.
14 Manipulate pack during opening.
15 Remove redundant Tear seal/autoplay controls.
16 Stronger artwork-related card entrances.
17 Exposed lower cards use actual shared franchise back art.
18 Retain cursor shine.
19 Unique colourful binder shapes.
20 Holographic sci-fi binder / fantasy scroll variants.
21 Correct foil pointer coordinate offset.
22 Artist Back restores prior card detail, filters, scroll and reveal position.
23 Larger recycling control.
24 Sleeve animation when protecting card.
25 Showcase preview / reversible popup from detail.
26 Free six-part binder colours; earned cosmetics change structure.
27 Visible Cover control.
28 Distinct illustrated backgrounds per space.
29 Showcase picker modal: universe then owned card, no detour.
30 Profile customizations, favourites/games/Steam profile showcase (manual demo, no implied integration).
31 Opening table above Universes.
32 Smooth pack manipulation.
33 Same physical interaction during opening.
34 Fix wrong-universe box queue; franchise box ceremonies.
35 Remove duplicate key; smooth lock interaction.
36 Smooth accurate shine.
37 Smooth directional card angle.
38 Visible key-turn animation.
39 Manipulate sealed pack directly on pack store.
40 Same arrow design for code and controls.

Scope: preserve inventory and print entitlements, local-only social/commerce, private access. Add natural finishing touches without fake live news, external posts or connected Steam claims. Existing screenshot attachments unavailable; written targets/comments authoritative. Validate code/domain and event flows; supported browser QA unavailable.

## Implementation and verification
All40 written items are implemented as local prototype behavior. The art package maps60 dedicated paintings plus3 existing premium overrides,3 dedicated pack illustrations and3 distinct room illustrations. Full2:3 card windows retain visual punchline props. No external daily-news feed or Steam integration is claimed; studio updates and manually entered Steam profile links are explicitly identified.

Pointer gestures are frame-scheduled, with foil coordinates measured on the foil surface. Hidden drags do not flip. Batch metadata separates newly purchased universes, protects old queued packs and enables automatic continuation. Older contiguous waiting packs acquire compatible batch metadata without changing inventory. The test suite verifies these states and event wiring, not actual browser layout or animation feel. Supported browser QA remains unavailable.
