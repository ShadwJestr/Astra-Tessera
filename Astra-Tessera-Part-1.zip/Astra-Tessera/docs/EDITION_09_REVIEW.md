# Astra Tessera — Edition 09

## Intent

Ravn requested one substantial update combining the latest annotation fixes, six collector features, a first-visit review, and a noticeable step toward finished visual quality. “Implemented” does not mean approved final art. Preserve the physical collecting feel, English art-specific humour, ownership, printing limits and working card shine.

## Delivered

- Contextual showcase navigation; compact favourite-game tiles whose dimensions do not depend on quantity.
- Card filing uses the actual tray rectangle in viewport coordinates and snaps into the tray; no arbitrary horizontal-distance threshold.
- Open-all results include bonus cosmetics. Closing the results returns to the completed opening table.
- Removed the redundant pack angle reset control.
- Opening environments change materials, frames, rails, controls, shapes and surrounding navigation per universe while retaining the neutral currency/back bar.
- Five purpose-made prestige-room artworks. New table cosmetics are extra collectibles, not replacements for the five regular cards.
- Deterministic collection milestones, claimable display objects, ornate and prestige tables, pinned completion goals, missing-card wishlisting and exact crafting costs.
- Collector room combining binders, favourite pulls, earned objects and two display arrangements; image export for sharing.
- Card memories, private notes and acquisition journal. Earlier ownership is explicitly undated; no invented historic dates.
- Four arrangeable nine-pocket print pages, quantity enforcement, downloadable page proof and an explicit review before replacing parcel card quantities.
- Local spectator window with revealed-card-only updates and reactions, intended for screen sharing. No remote social backend is claimed.
- Global search, a short first-visit path, help, update announcements and an in-site Design review.

## Latest annotation disposition

1. Showcase highlight: active only in its own view.
2–3. Favourite games: fixed-size wrapping tiles.
4. Dragging past pulls: actual target geometry and automatic filing.
4–5. Whole universe opening space: distinct furniture and structural styling, not only a background swap.
6. Open-all dismissal: stays on the completed table.
7. Reset angle: removed.
8. Clockwork mechanism: retained; praised direction is not discarded.
9. Elaborate unlockable tables: additional collectible rewards and collection milestones.

## Design decisions awaiting Ravn's judgment

| Area | Current decision | What remains uncertain or provisional |
|---|---|---|
| Card art | Preserve existing paintings and the working shine | Existing paintings are concept art. Each card still needs individual composition, anatomy, detail and consistency review; not all art is declared final. |
| World identity | Five distinct visual languages, materials and control furniture | Whether the user wants stronger divergence in card illustration styles too. |
| Prestige environments | Rich architecture surrounds a quieter card-handling area | Whether they are elaborate enough; responsive crops and readable contrast need visual approval. |
| Physicality | Layered illustration/CSS furniture, tilt, spring-back and tray snapping | These are not full 3D spaces. Exact weight, tilt limits, clipping and animation smoothness need real browser evaluation. |
| Collector room | Curated gallery/study layouts with movable collection items | A fully free room editor, arbitrary object placement and more showcase slots are not included. |
| Rewards | Predictable milestones alongside extra table collectibles | Exact progression thresholds and duplicate cosmetic treatment need product tuning. |
| Print proof | Editable nine-pocket page with owned-copy checks | This is a visual planning export, not printer-ready colour-managed artwork or a physical fulfilment integration. |
| Social | Local spectator screen and local prototype social features | Real remote rooms, accounts, moderation, cloud ownership and cross-device syncing require a backend phase. |
| Commerce | Existing simulated parcel flow | No real payment, shipping, licensed franchise partnership or production service is represented as active. |

## Verification

59 automated tests pass, including the expanded app smoke journey: collector routes, milestone selection, print planning, batch-result return, physical tray filing and spectator privacy. Asset paths, module syntax and package contents are checked separately before publication.

Supported browser automation is unavailable in this environment. DOM stubs exercise actions and state transitions; they do not establish pixel-perfect responsive layout, animation smoothness, real pointer capture, popup behaviour or export appearance. The artwork was visually inspected as individual assets. Those are distinct levels of evidence.

## Reference research

- Steam Trading Cards: collections can lead to visible profile expression and completion rewards. https://steamcommunity.com/tradingcards/?l=english
- Steam Trading Cards FAQ: readable collection progress. https://steamcommunity.com/tradingcards/faq/I?l=english
- Discogs collection/wantlist notes: give collectors a personal record beside ownership. https://support.discogs.com/hc/en-us/articles/360007425393-How-Can-I-Add-Collection-Wantlist-Notes
- TCGplayer saved/shared lists: reduce the friction between collecting intentions and a reusable list. https://help.tcgplayer.com/hc/en-us/articles/115009506287-Saving-and-Sharing-Lists

These informed interaction patterns. No page, brand identity or proprietary artwork was copied. Speculation, card-market prices, artificial urgency and daily streak pressure were deliberately not added.
