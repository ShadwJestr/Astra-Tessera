# Edition 12 — Design Lab and handling repair

## What changed
- Restored the earlier card-drag rotation from source revision 09d685a: sideways bend, vertical lean and in-plane rotation. Pack-preview rotation remains separate. Modern bounds and release-only filing retained.
- Increased neighbour repulsion from 28px/3 degrees to a middle-ground 58px/5 degrees, retaining gradual proximity response and return.
- Opening-table entry scrolls the currency/back bar just above the viewport; sidebar and end actions remain accessible. The top bar is no longer sticky on the active opening screen.
- Fixed card and action layout slots, with a consistent card footprint face-up or face-down, so the first reveal does not change the button position.
- Fixed a CSS naming collision between table-frame corners and card-frame corners.
- Binder-customizer dimensions and design-list allocation stay stable through filters; reduced wasted space and kept trim controls independent.
- Removed redundant bottom pagination controls, retained top count and sticky side arrows, strengthened the page-turn transition.
- Protected cards show a fitted sleeve throughout the binder. Decorative sleeve rewards remain future work; the Lab previews their visual possibilities.
- Collector directory links now navigate to full fictional visitor profiles, with showcase and featured-world binder.
- Long print/merch page receives a second layered background treatment.
- Table previews include a miniature card/tray layout and distinct base, milestone and prestige structure.

## Design Lab
Accessible in the sidebar. This is an isolated in-site experimental area, not a separate deployment or Git branch. It deliberately does not write inventory, credits, rewards or normal room selections.
- Four table compositions per world: current baseline, museum vitrine, world window, collector's atelier.
- Four sleeve studies: crystal, gilded, moon garden, holographic.
- Three motion studies: calm, balanced, lively, with replay.
- Favourite table direction stored under a separate localStorage key. It is a preference for comparison, never automatic adoption.
- Experiments are intentionally bolder than the normal site; approved directions can be brought across later.

## Validation and limits
69 automated tests passed. An additional application smoke pass exercises Lab variants, sleeve/motion selection, preference saving and visitor profiles, checking that collection inventory is unchanged. These are DOM-stub checks, not real-browser visual verification. Supported browser tooling remains unavailable, so handling feel, viewport alignment and art composition still need user review.

The two art-reference folders are still pending. No claim that existing artwork is final. The requested phone redesign, illustrated-binder per-part recolouring and real decorative-sleeve unlock system remain deferred. Currency and commerce remain fictional.
