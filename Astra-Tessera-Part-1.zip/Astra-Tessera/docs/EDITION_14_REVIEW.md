# Edition 14 — Repair and comparison pass

## Repairs
- One shared opening-controls renderer serves full page and local reveal updates. Reveal, Next and repeat purchase occupy the same first control slot. Secondary completion actions sit below it.
- Completion uses the same width and height as the card; controls are card-width, without an active-stage panel.
- Upper drag boundary reaches the progress-caption line. Side and lower bounds, original fluid drag rotations, hidden-card behaviour and release-only filing remain.
- Reordering previews the intervening items moving toward the held item's vacant slot, in either direction and across rows. Displacement grows on approach and reverses on retreat. Unrelated items remain stationary; order saves only on release.
- Lab manual pickup leaves the stack at eye level without revealing. First reveal is explicit, subsequent sample cards remain face-up.

## Lab
Only Dungeon and Moonlit scenes are affected. Cabinet adds posts, canopy and sill; desk adds a curved working surface and inset writing plate; classic uses a distinct framed presentation surface; open scene retains the landscape composition.
Twelve independently combinable, saveable layers: frame, foreground objects, glass, ambient light, motes, inlay, drapes, hanging lights, mist, stars, inscribed trim and display ledge. Selected controls have checkmarks and an enabled count. The previous toggle logic already merged options; the expanded tests verify simultaneous choices and persistence rather than assuming an unproven cause.
Approved attached sleeve materials and balanced default motion are preserved. No currency or collection mutation comes from experiments.

## Verification and limits
73 automated checks passed, including domain tests and a DOM-stub application flow. Added bidirectional and multirow vacancy tests; sample drag pickup, sample face-up continuation, concurrent detail toggles, and saved combination assertions. Existing stationary click, hidden drag, release filing, purchases and inventory preservation checks remain passing.
No supported browser QA tooling is available in this environment. These are not screenshot or real pointer rendering tests. Exact visual placement, layering and motion feel still need user review. Current Lab designs remain experiments, not approved final art. The separate reference folders and final mobile design remain pending.
