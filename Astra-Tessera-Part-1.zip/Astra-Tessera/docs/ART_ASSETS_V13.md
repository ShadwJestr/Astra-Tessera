# Edition 13 immersive room experiments

Two original scene illustrations generated with built-in image_gen. Both inspected: clear center tabletop, physically consistent seated perspective, side props, no UI/text/people. These are integrated scene experiments for Dungeon and Moonlit only.

## donjon

Path: `dist/assets/v13/donjon-scene.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-703f0e81-13d8-4379-bd56-bbbc1b3fd82b.png`

Prompt:

Use case: stylized-concept. Original high-end fantasy game environment illustration, widescreen 16:9, designed as an immersive collectible card opening room. View from a seated collector, eye level, not overhead. Foreground lower 38 percent is a broad clean UNOBSTRUCTED burgundy leather tabletop inset in beautifully aged dark walnut, its near edge cropped by image bottom. All center tabletop area must stay calm and empty for playable card interface. Beyond the desk: a collector's tavern vault carved into a vast cavern, arched stone opening overlooking a still dark turquoise underground lake and distant ruined castle lit by scattered amber windows. Warm brass lamps and carved woodwork at far sides. At extreme left only, a candle and purple potion bottle; tiny tasteful duck-shaped brass motifs integrated in side rail corners, not central ornaments. Rich architectural depth, inviting amber foreground against cool blue cavern distance, purposeful readable silhouettes and refined materials, polished intentional game concept painting, detailed focal architecture with calmer surfaces. Beautiful atmospheric depth without fog hiding everything. No cards, books, words, letters, UI, people, logos, watermark, excessive tiny ornaments, grit or grain. Table and background must belong to same perspective and scene, no pasted prop look.

## moonlit

Path: `dist/assets/v13/moonlit-scene.webp`

Original: `/workspace/scratch/9f8298f0e77d/generated_images/exec-5a49093f-b2d4-44c8-a6bd-af565a45e3b5.png`

Prompt:

Use case: stylized-concept. Original high-end fantastical midnight hotel game environment illustration, widescreen 16:9, designed as an immersive collectible card opening room. View from a seated collector on a grand moonlit hotel terrace, eye level, not overhead. Foreground lower 38 percent is a broad clean UNOBSTRUCTED deep indigo velvet tabletop with elegantly thin silver crescent-patterned perimeter, near edge cropped by image bottom. Center tabletop area calm and empty for playable card interface. Beyond it an elegant arched stone and silver balustrade, luminous moonflower garden, reflected moonlight in garden pools, and graceful fantastical hotel towers with inviting warm windows among indigo trees. Side curtains and ornamental arch frame view but central vista open. At extreme sides a few white moonflowers and small candles; no central props. Refined silver, indigo and violet with restrained warm gold windows. Beautiful composition and architectural depth, intentional polished game concept painting, strong clear forms, gorgeous atmospheric lighting and believable materials, details concentrated at edges and distant hotel rather than uniform noise. Integrated perspective table and surroundings. No cards, books, people, words, letters, UI, logos, watermark, excessive tiny ornament, grit or grain.

## Composition notes

Dungeon tabletop begins at approximately 58% image height; Moonlit tabletop begins at approximately 64%. Keep the lower foreground visible when fitting the scene to a viewport. Card UI may rise above the horizon while its base rests on the surface. Avoid adding duplicate large prop sprites over the already integrated side details. Both scenes retain open central lower surfaces.