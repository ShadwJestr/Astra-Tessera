@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Ask Codex to help install Node.js or use Python.
  pause
  exit /b 1
)
echo Open http://localhost:8000 in your browser.
echo Keep this window open while using the local site. Ctrl+C stops it.
node tools\serve.mjs
pause
